{{-- @include('layout.header') --}}
{{-- @stack('css')
@include('layout.leftpanel') --}}
{{-- @include('layout.topbar') --}}

{{-- @yield('content') --}}

{{-- @include('layout.footer')
@stack('javascript') --}}
