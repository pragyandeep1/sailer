<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <div class="wrapper">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3>Current Stock</h3>
                    </div>
                </div>
                
            </div>
            <div class="whitebox">
                <table id="stocksList" class="table table-striped table-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">S#</th>
                            <th scope="col">Stock Item</th>
                            <th scope="col">Location</th>
                            <th scope="col">Aisle</th>
                            <th scope="col">Row</th>
                            <th scope="col">Bin</th>
                            <th scope="col">Qty on Hand</th>
                            <th scope="col">Min Qty</th>
                            <th scope="col">Max Qty</th>

                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $stockLocation = json_decode($stock->location, true);
                                // $stockQuantity = json_decode($stock->quantity, true);
                            ?>
                            <tr style="cursor: pointer">
                                <th scope="row"><?php echo e($loop->iteration); ?></th>

                                <td><?php echo e($supplies[$stock->asset_id]); ?></td>

                                <td>
                                    <?php if(isset($facilities[$stock->parent_id])): ?>
                                        <?php echo e($facilities[$stock->parent_id]); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($stock['stocks_aisle']); ?></td>
                                <td><?php echo e($stock['stocks_row']); ?></td>
                                <td><?php echo e($stock['stocks_bin']); ?></td>
                                <td><?php echo e($stock->stocks_qty_on_hand); ?></td>
                                <td><?php echo e($stock->stocks_min_qty); ?></td>
                                <td><?php echo e($stock->stocks_max_qty); ?></td>

                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <span class="text-info">
                                    <strong>No Stock Found!</strong>
                                </span>
                            </td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php endif; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pms\resources\views/stocks/index.blade.php ENDPATH**/ ?>