<div id="content">
    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar static-top">
        <div class="container">
        <div class="toggle_button d-md-inline">
            <button id="sidebarToggle" class="" type="button">
                <i class="fa fa-bars-staggered"></i>
            </button>
        </div>

        <ul class="navbar-nav ml-auto ms-md-auto align-items-center">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown no-arrow user_prof">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="d-none d-lg-inline"><?php echo e(Auth::user()->name); ?></span>
                        <img class="img-profile rounded-circle" src="<?php echo e(asset('img/undraw_profile.svg')); ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                       
                        <a class="dropdown-item" href="<?php echo e(route('settings')); ?>">
                            <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                            Settings
                        </a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                 document.getElementById('logout-form').submit();">
                            
                            <i class="fa-solid fa-power-off fa-sm fa-fw mr-2 text-gray-400"></i>
                            <?php echo e(__('Log Off')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
		</div>
    </nav>
    <!-- End of Topbar -->
<?php /**PATH C:\xampp\htdocs\pms\resources\views/layout/topbar.blade.php ENDPATH**/ ?>