<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-dark accordion" id="accordionSidebar">

    <a class="sidebar-brand d-flex align-items-center justify-content-sm-start" href="<?php echo e(url('/')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <!-- <i class="fas fa-laugh-wink"></i> -->
            <img src="<?php echo e(asset('img/logo-icon.webp')); ?>" alt="img" class="img-fluid">
        </div>
        <div class="sidebar-brand-text mx-2">Sailorcom</div>
    </a>
    <hr class="sidebar-divider my-0">
    <li class="nav-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
            <i class="fa-solid fa-house"></i>
            <span>Dashboard</span></a>
    </li>
    
    <li class="nav-item <?php echo e(request()->is(['tools', 'equipments', 'facilities', 'assets']) ? 'active' : ''); ?>">
        <a class="nav-link <?php echo e(request()->is(['tools', 'equipments', 'facilities', 'assets']) ? '' : 'collapsed'); ?>"
            href="#" data-bs-toggle="collapse" data-bs-target="#assets"
            aria-expanded="<?php echo e(request()->is(['tools', 'equipments', 'facilities', 'assets']) ? 'true' : 'false'); ?>"
            aria-controls="assets">
            <i class="fa-solid fa-toolbox"></i>
            <span>Assets</span>
        </a>
        <ul id="assets"
            class="collapse collapse-inner rounded <?php echo e(request()->is(['tools', 'equipments', 'facilities', 'assets']) ? '' : ''); ?>"
            aria-labelledby="headingUtilities" data-bs-parent="#accordionSidebar">
            <li class="collapse-item">
                <div class="subhead">Assets</div>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['assets']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-asset', 'create-asset', 'edit-asset', 'delete-asset'])): ?>
                    <a href="<?php echo e(route('assets.index')); ?>"><i class="fa-solid fa-truck-ramp-box"></i> All
                        Assets</a>
                <?php endif; ?>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['facilities']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-facility', 'create-facility', 'edit-facility', 'delete-facility'])): ?>
                    <a href="<?php echo e(route('facilities.index')); ?>"><i class="fa-solid fa-warehouse"></i> Manage
                        Facilities</a>
                <?php endif; ?>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['equipments']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-equipment', 'create-equipment', 'edit-equipment', 'delete-equipment'])): ?>
                    <a href="<?php echo e(route('equipments.index')); ?>"><i class="fa-solid fa-people-carry-box"></i> Manage
                        Equipments</a>
                <?php endif; ?>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['tools']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-tools', 'create-tools', 'edit-tools', 'delete-tools'])): ?>
                    <a href="<?php echo e(route('tools.index')); ?>"><i class="fa-solid fa-screwdriver-wrench"></i> Manage
                        Tools</a>
                <?php endif; ?>
            </li>
        </ul>
    </li>
    <li class="nav-item <?php echo e(request()->is(['supplies', 'stocks', 'businesses']) ? 'active' : ''); ?>">
        <a class="nav-link" href="#" data-bs-toggle="collapse" data-bs-target="#supplies" aria-expanded="false"
            aria-controls="supplies">
            <i class="fa-solid fa-truck-moving"></i>
            <span>Supplies</span>
        </a>
        <ul id="supplies" class="collapse collapse-inner rounded" aria-labelledby="headingUtilities"
            data-bs-parent="#accordionSidebar">
            <li class="collapse-item">
                <div class="subhead">Supplies</div>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['supplies']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-supply', 'create-supply', 'edit-supply', 'delete-supply'])): ?>
                    <a href="<?php echo e(route('supplies.index')); ?>"><i class="fa-solid fa-truck-ramp-box"></i> Parts And
                        Supplies</a>
                <?php endif; ?>
            </li>

            <li class="collapse-item <?php echo e(request()->is(['stocks']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-stock', 'create-stock', 'edit-stock', 'delete-stock'])): ?>
                    <a href="<?php echo e(route('stocks.index')); ?>"><i class="fa-solid fa-layer-group"></i> Current Stock</a>
                <?php endif; ?>
            </li>
            
            
            
            
            
            
            
            
            
            
            <li class="collapse-item <?php echo e(request()->is(['businesses']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-business', 'create-business', 'edit-business', 'delete-business'])): ?>
                    <a href="<?php echo e(route('businesses.index')); ?>"><i class="fa-solid fa-building"></i> Businessess</a>
                <?php endif; ?>
            </li>
        </ul>
    </li>
    <li class="nav-item <?php echo e(request()->is(['users', 'roles', 'positions']) ? 'active' : ''); ?>">
        <a class="nav-link" href="#" data-bs-toggle="collapse" data-bs-target="#settings" aria-expanded="false"
            aria-controls="settings">
            <i class="fa-solid fa-gear"></i>
            <span>Settings</span>
        </a>
        <ul id="settings" class="collapse collapse-inner rounded" aria-labelledby="headingUtilities"
            data-bs-parent="#accordionSidebar">
            <li class="collapse-item">
                <div class="subhead">Settings</div>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['users']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-user', 'create-user', 'edit-user', 'delete-user'])): ?>
                    <a href="<?php echo e(route('users.index')); ?>"><i class="bi bi-people"></i> Manage
                        Users</a>
                <?php endif; ?>
            </li>

            <li class="collapse-item <?php echo e(request()->is(['roles']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-role', 'create-role', 'edit-role', 'delete-role'])): ?>
                    <a href="<?php echo e(route('roles.index')); ?>"><i class="fa-solid fa-user-tie"></i> Manage
                        Roles</a>
                <?php endif; ?>
            </li>
            <li class="collapse-item <?php echo e(request()->is(['positions']) ? 'active-class' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-position', 'create-position', 'edit-position', 'delete-position'])): ?>
                    <a href="<?php echo e(route('positions.index')); ?>"><i class="fa-solid fa-user-plus"></i> Manage
                        Positions</a>
                <?php endif; ?>
            </li>
            
        </ul>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#" data-bs-toggle="collapse" data-bs-target="#managelists" aria-expanded="false"
            aria-controls="managelists">
            <i class="fa-solid fa-rectangle-list"></i>
            <span>Manage Lists</span>
        </a>
        <ul id="managelists" class="collapse collapse-inner rounded" aria-labelledby="headingUtilities"
            data-bs-parent="#accordionSidebar">
            <li class="collapse-item">
                <div class="subhead">Manage Lists</div>
            </li>
            <li class="collapse-item">
                <a href="<?php echo e(route('category.index')); ?>"><i class="fa-solid fa-layer-group"></i>
                    Asset Category</a>
            </li>
            <li class="collapse-item">
                <a href="<?php echo e(route('account.index')); ?>"><i class="fa-solid fa-file-invoice"></i>
                    Asset Account
                </a>
            </li>
            <li class="collapse-item">
                <a href="<?php echo e(route('charge.index')); ?>"><i class="fa-solid fa-file-invoice-dollar"></i>
                    Asset Charge
                    Department
                </a>
            </li>
            <li class="collapse-item">
                <a href="<?php echo e(route('meter.index')); ?>"><i class="fa-solid fa-chart-line"></i>
                    Meter Reading
                    Units
                </a>
            </li>
            <li class="collapse-item">
                <a href="<?php echo e(route('currency.index')); ?>"><i class="fa-solid fa-wallet"></i></i>
                    Currency Units
                </a>
            </li>
            <li class="collapse-item">
                <a href="<?php echo e(route('businessclassification.index')); ?>"><i class="fa-solid fa-briefcase"></i>
                    Business
                    Classification
                </a>
            </li>
        </ul>
    </li>
    <hr class="sidebar-divider my-0">

    <li class="nav-item">
        <a class="nav-link dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
    document.getElementById('logout-form').submit();">
            <i class="fa-solid fa-power-off" style="color: #53b6f0;"></i>
            <span class=""> <?php echo e(__('Log Off')); ?></span> </a>
    </li>
    <div class="text-center d-none d-md-inline mt-4">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
<?php /**PATH C:\xampp\htdocs\pms\resources\views/layout/leftpanel.blade.php ENDPATH**/ ?>