<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <div class="wrapper">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3>Tools List</h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-tools')): ?>
                        <a href="<?php echo e(route('tools.create')); ?>" class="btn btn-primary float-end"><i class="bi bi-plus-circle"></i>
                            Add New
                            Tool</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="whitebox">
                <table id="ToolsList" class="table table-striped nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">S#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Code</th>
                            <th scope="col">Status</th>
                            
                            <th scope="col">Asset Location</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($tool->name); ?></td>
                                <td><?php echo e($tool->code); ?></td>
                                <td><?php echo e($tool->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                <td>
                                    <?php if(
                                        $tool->assetAddress &&
                                            $tool->assetAddress->parent_id &&
                                            ($parentFacility = $allfacilities->where('id', $tool->assetAddress->parent_id)->first())): ?>
                                        <?php echo e($parentFacility->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('tools.destroy', $tool->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-tools')): ?>
                                            <a href="<?php echo e(route('tools.edit', $tool->id)); ?>" class="link-primary"><i
                                                    class="fa-regular fa-pen-to-square"></i></a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-tools')): ?>
                                            <button type="submit" class="link-danger"
                                                onclick="return confirm('Do you want to delete this asset?');"><i
                                                    class="fa-solid fa-trash-can"></i></button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <span class="text-danger">
                                    <strong>No Asset Found!</strong>
                                </span>
                            </td>
                            <td></td>
                            <td></td>
                        <?php endif; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/busfaypa/public_html/webiconnect.net/dev/pms/resources/views/tools/index.blade.php ENDPATH**/ ?>