<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="page-content container">
    <div class="wrapper">
        <div class="row align-items-center">
            <div class="col-md-9">
                <div class="page-header">
                    <h3>Assets List</h3>
                </div>
            </div>
            <div class="col-md-3">
                <a data-bs-toggle="modal" data-bs-target="#CreateAssetModal" class="btn btn-primary float-end" style="cursor:pointer"><i class="bi bi-plus-circle"></i> Add New
                    Asset</a>
            </div>
        </div>
        <div class="whitebox">
            <table id="ProductsList" class="table table-striped nowrap" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">Hierarchy</th>
                        <th scope="col">Name</th>
                        <th scope="col">Category</th>
                        <th scope="col">Status</th>
                        
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($facility['name']); ?></td>
                        <td><?php echo e($facility['name']); ?></td>
                        <td><?php echo e('Facility'); ?></td>
                        <td><?php echo e($facility['status'] == '1' ? 'Active' : 'Inactive'); ?></td>
                        <td>
                            <form action="<?php echo e(route('facilities.destroy', $facility['id'])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <a href="<?php echo e(route('facilities.show', $facility['id'])); ?>" class="btn btn-warning btn-sm"><i class="bi bi-eye"></i> </a>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-facility')): ?>
                                <a href="<?php echo e(route('facilities.edit', $facility['id'])); ?>" class="link-primary"><i class="fa-regular fa-pen-to-square"></i></a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-facility')): ?>
                                <button type="submit" class="link-danger" onclick="return confirm('Do you want to delete this facility?');"><i class="fa-solid fa-trash-can"></i></button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    
                    
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="modal fade" id="CreateAssetModal" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <h6 class="modal-title">Create New Asset</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"><i class="fa-solid fa-xmark"></i></button>
                <div class="row align-items-center justify-content-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-facility', 'create-facility', 'edit-facility', 'delete-facility'])): ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('facilities.create')); ?>" class="border-purple">
                            <div class="d-flex">
                                <span class="me-2"><img src="<?php echo e(asset('img/location_icon.png')); ?>" alt="img" class="img-fluid"></span>
                                <span class="mt-2">Locations or Facilities</span>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-equipment', 'create-equipment', 'edit-equipment', 'delete-equipment'])): ?>
                    <div class="col-md-6">

                        <a href="<?php echo e(route('equipments.create')); ?>" class="border-purple">
                            <div class="d-flex">
                                <span class="me-2"><img src="<?php echo e(asset('img/machine_icon.png')); ?>" alt="img" class="img-fluid"></span>
                                <span class="mt-2">Equipment or Machines</span>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-tools', 'create-tools', 'edit-tools', 'delete-tools'])): ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('tools.create')); ?>" class="border-purple">
                            <div class="d-flex">
                                <span class="me-2"><img src="<?php echo e(asset('img/tool_icon.png')); ?>" alt="img" class="img-fluid"></span>
                                <span class="mt-4">Tools</span>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pms\resources\views/assets/index.blade.php ENDPATH**/ ?>