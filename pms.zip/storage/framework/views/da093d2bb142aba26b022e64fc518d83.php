<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <div class="wrapper">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3>Manage Roles</h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-role')): ?>
                        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary float-end"><i class="bi bi-plus-circle"></i>
                            Add New Role</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="whitebox">

                <table id="RolesList" class="table table-striped nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">S#</th>
                            <th scope="col">Name</th>
                            <th scope="col" style="width: 250px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($role->name); ?></td>
                                <td>
                                    <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        

                                        <?php if($role->name != 'Super Admin'): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-role')): ?>
                                                <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="link-primary"><i
                                                        class="fa-regular fa-pen-to-square"></i></a>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-role')): ?>
                                                <?php if($role->name != Auth::user()->hasRole($role->name)): ?>
                                                    <button type="submit" class="link-danger"
                                                        onclick="return confirm('Do you want to delete this role?');"><i
                                                            class="fa-solid fa-trash-can"></i></button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td></td>

                            <td>
                                <span class="text-danger">
                                    <strong>No Role Found!</strong>
                                </span>
                            </td>
                            <td></td>
                        <?php endif; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pms\resources\views/roles/index.blade.php ENDPATH**/ ?>