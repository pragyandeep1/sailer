<?php $__env->startPush('css'); ?>
    <style>
        .ShowtocksModal {
            z-index: 1070 !important;
        }

        .UploadStocksModal {
            z-index: 1080 !important;
        }

        .UploadSupBomModal {
            z-index: 1090 !important;
        }

        .ShowAssetsModal {
            z-index: 1100 !important;
        }

        .CreateAssetModal {
            z-index: 1110 !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $current_date_time = \Carbon\Carbon::now();
        if (isset($supply->assetGeneralInfo) && $supply->assetGeneralInfo != 'null') {
            $assetGeneralInfo = $supply->assetGeneralInfo;
        }
        if (isset($supply->assetFiles) && $supply->assetFiles != 'null') {
            $assetFiles = $supply->assetFiles;
        }
        if (isset($supply->stocks) && $supply->stocks != 'null') {
            $stocks = $supply->stocks;
        }
        if (isset($supply->inventories) && $supply->inventories != 'null') {
            $inventories = $supply->inventories;
        }
        if (isset($supply->assetWarranty) && $supply->assetWarranty != 'null') {
            $assetWarranty = $supply->assetWarranty;
        }
        if (isset($supply->assetUser) && $supply->assetUser != 'null') {
            $assetUser = $supply->assetUser;
        }
        if (isset($supply->assetPartSuppliesLog) && $supply->assetPartSuppliesLog != 'null') {
            $assetPartSuppliesLog = $supply->assetPartSuppliesLog;
        }

        // echo '<pre>';
        // print_r($stocks);
        // echo '</pre>';
        // print_r($assetAddress);
        // echo $address['address'];
        // print_r($supply->assetGeneralInfo);

    ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <form action="<?php echo e(route('supplies.update', $supply->id)); ?>" method="post" enctype="multipart/form-data"
            id="supplyUpdateForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="wrapper">
                <div class="status_bar">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <div class="page-header">
                                <h3> Edit Supply <?php if(!empty($supply->id)): ?>
                                        <span class="text-info"> <a href="javascript:void(0)"
                                                class="btn btn-info btn-sm"><?php echo e($supply->name); ?>

                                                (<?php echo e($supply->code); ?>)</a><span>
                                    <?php endif; ?>
                                </h3>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="float-end">
                                <div class="status_area">
                                    <ul>
                                        <li>
                                            <h3>Status</h3>
                                        </li>
                                        <li>
                                            <select class="form-select" aria-label="Default select example" name="status">
                                                <option value="1" <?php echo e($supply->status == 1 ? 'selected' : ''); ?>>Active
                                                </option>
                                                <option value="0" <?php echo e($supply->status == 0 ? 'selected' : ''); ?>>
                                                    Disable
                                                </option>
                                            </select>
                                        </li>
                                        <li>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fa-solid fa-floppy-disk"></i> Publish
                                            </button>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('supplies.index')); ?>" class="btn btn-primary float-end">
                                                <i class="fa-solid fa-list me-1"></i>All Supplies
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" value="<?php echo e($supply->id); ?>" name="supply_id" id="AssetID">
                <div class="nav_tab_area">
                    <ul class="nav nav-tabs mb-3" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" aria-current="page" href="#userBasic">Basic</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userStock">Stock</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userboms">BOMs</a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userWarranties">Warranties</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userFiles">Files</a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="userBasic">

                            <div class="whitebox mb-4">
                                <div class="page-header mb-2">
                                    <h3>Basic Details</h3>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="name" class="col-form-label text-md-end text-start">Supply
                                            name</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="name" name="name" value="<?php echo e($supply->name); ?>" autocomplete="off">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="code" class="col-form-label text-md-end text-start">Code</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="code" name="code" value="<?php echo e($supply->code); ?>">
                                        <?php if($errors->has('code')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="category_id" class="col-form-label text-md-end text-start">Category
                                        </label>
                                        <select class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Category" id="category_id" name="category_id">
                                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($id); ?>"
                                                    <?php echo e($supply->category_id == $id ? 'selected' : ''); ?>>
                                                    <?php echo e($category); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('category_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('category_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="description"
                                            class="col-form-label text-md-end text-start">Description</label>
                                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description"
                                            cols="48" rows="6"><?php echo e($supply->description); ?></textarea>
                                        <?php if($errors->has('description')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userStock">
                            <ul class="nav nav-tabs" id="myTabs2">
                                <li class="nav-item">
                                    <a class="nav-link active" data-bs-toggle="tab" aria-current="page"
                                        href="#stockGeneral">General</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#stockStocks">Stock initialization</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#stockInventory">Stock purchase</a>
                                </li>
                            </ul>
                            <div class="item_name">
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="stockGeneral">

                                        <div class="whitebox mb-4">
                                            <div class="page-header mb-2">
                                                <h3>General Details</h3>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="account"
                                                        class="col-form-label text-md-end text-start">Account
                                                    </label>
                                                    <?php
                                                        // print_r($accounts);
                                                    ?>
                                                    <select class="form-control <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        aria-label="Account" id="account" name="account">
                                                        <option value="">--Select--</option>
                                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($account['id']); ?>"
                                                                <?php echo e($assetGeneralInfo->accounts_id == $account['id'] ? 'selected' : ''); ?>>
                                                                (<?php echo e($account['code']); ?>)
                                                                <?php echo e($account['description']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('account')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('account')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="department"
                                                        class="col-form-label text-md-end text-start">Charge
                                                        Departments
                                                    </label>
                                                    <?php
                                                        // print_r($departments);
                                                    ?>
                                                    <select class="form-control <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        aria-label="Departments" id="department" name="department">
                                                        <option value="">--Select--</option>
                                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($department['id']); ?>"
                                                                <?php echo e($assetGeneralInfo->charge_department_id == $department['id'] ? 'selected' : ''); ?>>
                                                                (<?php echo e($department['code']); ?>)
                                                                <?php echo e($department['description']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('department')): ?>
                                                        <span
                                                            class="text-danger"><?php echo e($errors->first('department')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="unspc_code"
                                                        class="col-form-label text-md-end text-start">Unspc Code
                                                    </label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['unspc_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="unspc_code" name="unspc_code"
                                                        value="<?php echo e($assetGeneralInfo->unspc_code ?? ''); ?>">
                                                    <?php if($errors->has('unspc_code')): ?>
                                                        <span
                                                            class="text-danger"><?php echo e($errors->first('unspc_code')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="barcode"
                                                        class="col-form-label text-md-end text-start">Barcode</label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="barcode" name="barcode"
                                                        value="<?php echo e($assetGeneralInfo->barcode ?? ''); ?>">
                                                    <?php if($errors->has('barcode')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('barcode')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="make"
                                                        class="col-form-label text-md-end text-start">Make
                                                    </label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="make" name="make"
                                                        value="<?php echo e($assetGeneralInfo->make ?? ''); ?>">
                                                    <?php if($errors->has('make')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('make')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="model"
                                                        class="col-form-label text-md-end text-start">Model</label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="model" name="model"
                                                        value="<?php echo e($assetGeneralInfo->model ?? ''); ?>">
                                                    <?php if($errors->has('model')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('model')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="last_price"
                                                        class="col-form-label text-md-end text-start">Last Price
                                                    </label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['last_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="last_price" name="last_price"
                                                        value="<?php echo e($assetGeneralInfo->last_price ?? ''); ?>">
                                                    <?php if($errors->has('last_price')): ?>
                                                        <span
                                                            class="text-danger"><?php echo e($errors->first('last_price')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="total_stock"
                                                        class="col-form-label text-md-end text-start">Total Stock
                                                    </label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['total_stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="total_stock" name="total_stock"
                                                        value="<?php echo e($totalStock ?? ''); ?>" readonly>
                                                    <?php if($errors->has('total_stock')): ?>
                                                        <span
                                                            class="text-danger"><?php echo e($errors->first('total_stock')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="notes"
                                                        class="col-form-label text-md-end text-start">Notes</label>
                                                    <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" id="notes" cols="48"
                                                        rows="6"><?php echo e($assetGeneralInfo->notes ?? ''); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="stockStocks">
                                        <div class="whitebox mb-4">
                                            <div class="page-header mb-2">
                                                <h3>Stocks Details</h3>
                                                <a data-bs-toggle="modal" data-bs-target="#UploadStocksModal"
                                                    class="btn btn-primary float-end" style="cursor:pointer"> <i
                                                        class="fa-solid fa-plus me-1"></i>Add new
                                                </a>
                                            </div>
                                            <div class="row">
                                                <div class="page-header">
                                                    <h3>Stock Levels Per Location</h3>
                                                    <hr>
                                                </div>
                                                <table class="display" id="StockList" width ="100%">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">S#</th>
                                                            <th scope="col">Location</th>
                                                            <th scope="col">Initial price</th>
                                                            <th scope="col">Aisle</th>
                                                            <th scope="col">Row</th>
                                                            <th scope="col">Bin</th>
                                                            <th scope="col">Qty on hand</th>
                                                            <th scope="col">Min qty</th>
                                                            <th scope="col">Max qty</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <?php
                                                                // $stockLocation = json_decode($stock->location, true);
                                                            ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                                <td>
                                                                    <?php if(isset($facilities[$stock->parent_id])): ?>
                                                                        <?php echo e($facilities[$stock->parent_id]); ?>

                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><?php echo e($stock->initial_price); ?></td>
                                                                <td><?php echo e($stock['stocks_aisle']); ?></td>
                                                                <td><?php echo e($stock['stocks_row']); ?></td>
                                                                <td><?php echo e($stock['stocks_bin']); ?></td>
                                                                <td><?php echo e($stock->stocks_qty_on_hand); ?></td>
                                                                <td><?php echo e($stock->stocks_min_qty); ?></td>
                                                                <td><?php echo e($stock->stocks_max_qty); ?></td>
                                                                <td>
                                                                    <a data-bs-toggle="modal"
                                                                        data-bs-target="#UpdateStocksModal_<?php echo e($stock->id); ?>"
                                                                        class="link-primary"><i
                                                                            class="fa-regular fa-pen-to-square"></i></a>
                                                                    <button type="button" class="link-danger"
                                                                        onclick="delete_stockdetails('<?php echo e(route('supplystocks.delete', $stock->id)); ?>')"
                                                                        data-id="<?php echo e($stock->id); ?>">
                                                                        <i class="fa-solid fa-trash-can"></i>
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                            
                                                            <div class="modal fade UpdateStocksModal"
                                                                id="UpdateStocksModal_<?php echo e($stock->id); ?>" tabindex="-1"
                                                                role="dialog" aria-hidden="true"
                                                                data-bs-keyboard="false" data-bs-backdrop="static">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                        <!-- Modal body -->
                                                                        <div class="modal-body">
                                                                            <h6 class="modal-title">Stock</h6>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"><i
                                                                                    class="fa-solid fa-xmark"></i></button>
                                                                            <div class="whitebox mb-4">
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="stocks_parent_facility_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Location</label>
                                                                                        <select
                                                                                            class="form-control <?php $__errorArgs = ['stocks_parent_facility'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            aria-label="stocks_parent_facility"
                                                                                            id="stocks_parent_facility_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_parent_facility">
                                                                                            <option value="">--None--
                                                                                            </option>
                                                                                            <?php $__empty_2 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                                <option
                                                                                                    value="<?php echo e($id); ?>"
                                                                                                    <?php echo e($stock->parent_id == $id ? 'selected' : ''); ?>>
                                                                                                    <?php echo e($facility); ?>

                                                                                                </option>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                            <?php endif; ?>
                                                                                        </select>
                                                                                        <?php if($errors->has('stocks_parent_facility')): ?>
                                                                                            <span
                                                                                                id="stocks_parent_facility-error_<?php echo e($stock->id); ?>"
                                                                                                class="text-danger"><?php echo e($errors->first('stocks_parent_facility')); ?></span>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="initial_price_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Initial
                                                                                            price
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['initial_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="initial_price_<?php echo e($stock->id); ?>"
                                                                                            name="initial_price"
                                                                                            placeholder="0.00"
                                                                                            value="<?php echo e($stock->initial_price); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-4">
                                                                                        <label
                                                                                            for="stocks_aisle_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Aisle
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['stocks_aisle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="stocks_aisle_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_aisle"
                                                                                            value="<?php echo e($stock->stocks_aisle); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-4">
                                                                                        <label
                                                                                            for="stocks_row_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Row
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['stocks_row'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="stocks_row_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_row"
                                                                                            value="<?php echo e($stock->stocks_row); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-4">
                                                                                        <label
                                                                                            for="stocks_bin_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Bin
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['stocks_bin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="stocks_bin_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_bin"
                                                                                            value="<?php echo e($stock->stocks_bin); ?>">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-4">
                                                                                        <label
                                                                                            for="stocks_qty_on_hand_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Qty
                                                                                            on hand
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['stocks_qty_on_hand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="stocks_qty_on_hand_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_qty_on_hand"
                                                                                            value="<?php echo e($stock->stocks_qty_on_hand); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-4">
                                                                                        <label
                                                                                            for="stocks_min_qty_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Min
                                                                                            qty
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['stocks_min_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="stocks_min_qty_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_min_qty"
                                                                                            value="<?php echo e($stock->stocks_min_qty); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-4">
                                                                                        <label
                                                                                            for="stocks_max_qty_<?php echo e($stock->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Max
                                                                                            qty
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['stocks_max_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="stocks_max_qty_<?php echo e($stock->id); ?>"
                                                                                            name="stocks_max_qty"
                                                                                            value="<?php echo e($stock->stocks_max_qty); ?>">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <button type="button"
                                                                                class="btn btn-primary mt-3 float-end save-stocks-btn"
                                                                                data-log-id="<?php echo e($stock->id); ?>">Update</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td><span class="text-info"><strong>No Logs
                                                                        Found!</strong></span></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="stockInventory">

                                        <div class="whitebox mb-4">
                                            <div class="page-header mb-2">
                                                <h3>Inventory Details</h3>
                                                <a data-bs-toggle="modal" data-bs-target="#UploadInventoryModal"
                                                    class="btn btn-primary float-end" style="cursor:pointer"> <i
                                                        class="fa-solid fa-plus me-1"></i>Add new
                                                </a>
                                            </div>
                                            <div class="row">
                                                <div class="page-header">
                                                    <h3>Receipt Line Item</h3>
                                                    <hr>
                                                </div>
                                                <table class="display" id="InventoryList" width ="100%">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">S#</th>
                                                            <th scope="col">Qty</th>
                                                            <th scope="col">Purchased from</th>
                                                            <th scope="col">Received to</th>
                                                            <th scope="col">Date Received</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <?php

                                                            ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                                <td><?php echo e($inventor['quantity_received']); ?></td>

                                                                <td>
                                                                    <?php if(isset($businesses[$inventor['purchased_from']])): ?>
                                                                        <?php echo e($businesses[$inventor['purchased_from']]); ?>

                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <?php
                                                                        $stock = $stocks
                                                                            ->where('id', $inventor['parent_id'])
                                                                            ->first();

                                                                        if ($stock) {
                                                                            $message =
                                                                                $supply->name .
                                                                                ' (' .
                                                                                $supply->code .
                                                                                ') at ' .
                                                                                $facilities[$stock->parent_id];
                                                                            echo $message;
                                                                        }
                                                                    ?>
                                                                </td>

                                                                <td><?php echo e(\Carbon\Carbon::parse($inventor['date_received'])->format('jS F, Y h:i A')); ?>

                                                                </td>
                                                                <td>
                                                                    <a data-bs-toggle="modal"
                                                                        data-bs-target="#UpdateInventoryModal_<?php echo e($inventor->id); ?>"
                                                                        class="link-primary"><i
                                                                            class="fa-regular fa-pen-to-square"></i></a>
                                                                    <button type="button" class="link-danger"
                                                                        onclick="delete_inventoriesdetails('<?php echo e(route('supplyinventories.delete', $inventor->id)); ?>')"
                                                                        data-id="<?php echo e($inventor->id); ?>">
                                                                        <i class="fa-solid fa-trash-can"></i>
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                            
                                                            <div class="modal fade"
                                                                id="UpdateInventoryModal_<?php echo e($inventor->id); ?>"
                                                                tabindex="-1" role="dialog" aria-hidden="true"
                                                                data-bs-keyboard="false" data-bs-backdrop="static">
                                                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                                                    <div class="modal-content">
                                                                        <!-- Modal body -->
                                                                        <div class="modal-body">
                                                                            <h6 class="modal-title">Asset Purchase
                                                                                Information</h6>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"><i
                                                                                    class="fa-solid fa-xmark"></i></button>
                                                                            <div class=""
                                                                                id="ajaxInventorymsg_<?php echo e($inventor->id); ?>">
                                                                            </div>
                                                                            <div class="whitebox mb-4">
                                                                                <div class="row">
                                                                                    <div class="col-md-6 item_name">
                                                                                        <label
                                                                                            for="inventory_purchased_from_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Purchased
                                                                                            From</label>
                                                                                        <select
                                                                                            class="form-control <?php $__errorArgs = ['inventory_purchased_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            aria-label="inventory_purchased_from"
                                                                                            id="inventory_purchased_from_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_purchased_from">
                                                                                            <option value="">--Select
                                                                                                Business--</option>
                                                                                            <?php $__empty_2 = true; $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                                <option
                                                                                                    value="<?php echo e($id); ?>"
                                                                                                    <?php echo e($inventor->purchased_from == $id ? 'selected' : ''); ?>>
                                                                                                    <?php echo e($business); ?>

                                                                                                </option>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                            <?php endif; ?>
                                                                                        </select>
                                                                                        <?php if($errors->has('inventory_purchased_from')): ?>
                                                                                            <span
                                                                                                class="text-danger"><?php echo e($errors->first('inventory_purchased_from')); ?></span>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                    <div class="col-md-6 item_name">
                                                                                        <label
                                                                                            for="inventory_purchase_currency_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Purchase
                                                                                            Currency</label>
                                                                                        <select
                                                                                            class="form-control <?php $__errorArgs = ['inventory_purchase_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            aria-label="inventory_purchase_currency"
                                                                                            id="inventory_purchase_currency_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_purchase_currency">
                                                                                            <option value="">--None--
                                                                                            </option>
                                                                                            <?php $__empty_2 = true; $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $currenci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                                <option
                                                                                                    value="<?php echo e($id); ?>"
                                                                                                    <?php echo e($inventor->purchase_currency == $id ? 'selected' : ''); ?>>
                                                                                                    <?php echo e($currenci); ?>

                                                                                                </option>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                            <?php endif; ?>
                                                                                        </select>
                                                                                        <?php if($errors->has('inventory_purchase_currency')): ?>
                                                                                            <span
                                                                                                class="text-danger"><?php echo e($errors->first('inventory_purchase_currency')); ?></span>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_date_ordered_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Date
                                                                                            Ordered
                                                                                        </label>
                                                                                        <input type="date"
                                                                                            class="form-control <?php $__errorArgs = ['inventory_date_ordered'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="inventory_date_ordered_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_date_ordered"
                                                                                            value="<?php echo e($inventor->date_ordered); ?>"
                                                                                            min="<?php echo e(date('Y-m-d')); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_date_received_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Date
                                                                                            Received
                                                                                        </label>
                                                                                        <input type="date"
                                                                                            class="form-control <?php $__errorArgs = ['inventory_date_received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="inventory_date_received_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_date_received"
                                                                                            value="<?php echo e($inventor->date_received); ?>"
                                                                                            min="<?php echo e(date('Y-m-d')); ?>">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_received_to_msg_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Received
                                                                                            To
                                                                                        </label>
                                                                                        <div class="input-group">
                                                                                            <input type="hidden"
                                                                                                class="form-control"
                                                                                                name="inventory_received_to"
                                                                                                id="inventory_received_to_<?php echo e($inventor->id); ?>"
                                                                                                value="<?php echo e($inventor->parent_id); ?>">
                                                                                            <input type="text"
                                                                                                id="inventory_received_to_msg_<?php echo e($inventor->id); ?>"
                                                                                                class="form-control <?php $__errorArgs = ['inventory_received_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                                value=" <?php $stock = $stocks
                                                                                                    ->where('id', $inventor['parent_id'])
                                                                                                    ->first();
                                                                                                if ($stock) {
                                                                                                    $message =
                                                                                                        $supply->name .
                                                                                                        ' (' .
                                                                                                        $supply->code .
                                                                                                        ') at ' .
                                                                                                        $facilities[$stock->parent_id];
                                                                                                    echo $message;
                                                                                                } ?>"
                                                                                                readonly>
                                                                                            <a data-bs-toggle="modal"
                                                                                                data-bs-target="#ShowtocksModal_<?php echo e($inventor->id); ?>"
                                                                                                class="btn btn-primary float-end"
                                                                                                style="cursor:pointer"> <i
                                                                                                    class="fa-solid fa-plus me-1"></i>
                                                                                            </a>
                                                                                            <?php if($errors->has('inventory_received_to')): ?>
                                                                                                <span
                                                                                                    id="inventory_received_to-error_<?php echo e($inventor->id); ?>"
                                                                                                    class="text-danger"><?php echo e($errors->first('inventory_received_to')); ?></span>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_quantity_received_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Quantity
                                                                                            Received
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['inventory_quantity_received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="inventory_quantity_received_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_quantity_received"
                                                                                            value="<?php echo e($inventor->quantity_received ?? '0'); ?>">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_purchase_price_per_unit_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Purchase
                                                                                            Price Per Unit
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['inventory_purchase_price_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="inventory_purchase_price_per_unit_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_purchase_price_per_unit"
                                                                                            value="<?php echo e($inventor->purchase_price_per_unit ?? '0'); ?>">
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_purchase_price_total_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Purchase
                                                                                            Price
                                                                                            Total
                                                                                        </label>
                                                                                        <input type="text"
                                                                                            class="form-control <?php $__errorArgs = ['inventory_purchase_price_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="inventory_purchase_price_total_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_purchase_price_total"
                                                                                            value="<?php echo e($inventor->purchase_price_total); ?>"
                                                                                            readonly>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <label
                                                                                            for="inventory_date_of_expiry_<?php echo e($inventor->id); ?>"
                                                                                            class="col-form-label text-md-end text-start">Date
                                                                                            of Expiry
                                                                                        </label>
                                                                                        <input type="date"
                                                                                            class="form-control <?php $__errorArgs = ['inventory_date_of_expiry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                            id="inventory_date_of_expiry_<?php echo e($inventor->id); ?>"
                                                                                            name="inventory_date_of_expiry"
                                                                                            value="<?php echo e($inventor->date_of_expiry); ?>"
                                                                                            min="<?php echo e(date('Y-m-d')); ?>">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <button type="button"
                                                                                class="btn btn-primary mt-3 float-end save-inventories-btn"
                                                                                data-log-id="<?php echo e($inventor->id); ?>">Update</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td><span class="text-info"><strong>No Logs
                                                                        Found!</strong></span></td>
                                                            <td></td>
                                                            <td></td>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                                
                                                <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <div class="modal fade ShowtocksModal"
                                                        id="ShowtocksModal_<?php echo e($inventor->id); ?>" tabindex="-1"
                                                        role="dialog" aria-hidden="true" data-bs-keyboard="false"
                                                        data-bs-backdrop="static">
                                                        <div class="modal-dialog  modal-dialog-centered modal-lg">
                                                            <div class="modal-content">
                                                                <!-- Modal body -->
                                                                <div class="modal-body">
                                                                    <h6 class="modal-title">Current Stock</h6>
                                                                    <a data-bs-toggle="modal"
                                                                        data-bs-target="#UploadStocksModal"
                                                                        class="btn btn-primary float-end mt-2 mb-2"
                                                                        style="cursor:pointer"> <i
                                                                            class="fa-solid fa-plus me-1"></i>Add new
                                                                    </a>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"><i
                                                                            class="fa-solid fa-xmark"></i></button>
                                                                    <table class="display table table-striped"
                                                                        id="" width ="100%">
                                                                        <thead>
                                                                            <tr>
                                                                                <th scope="col">S#</th>
                                                                                <th scope="col">Location</th>
                                                                                <th scope="col">Aisle</th>
                                                                                <th scope="col">Row</th>
                                                                                <th scope="col">Bin</th>
                                                                                <th scope="col">Qty on hand</th>
                                                                                <th scope="col">Min qty</th>
                                                                                <th scope="col">Max qty</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php $__empty_2 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                <tr class="inventories-row-modal"
                                                                                    data-id="<?php echo e($stock->id); ?>"
                                                                                    data-tableid="<?php echo e($inventor->id); ?>"
                                                                                    style="cursor: pointer">
                                                                                    <th scope="row">
                                                                                        <?php echo e($loop->iteration); ?></th>
                                                                                    <td>
                                                                                        <?php if(isset($facilities[$stock->parent_id])): ?>
                                                                                            <?php echo e($facilities[$stock->parent_id]); ?>

                                                                                        <?php endif; ?>
                                                                                    </td>
                                                                                    <td><?php echo e($stock['stocks_aisle']); ?></td>
                                                                                    <td><?php echo e($stock['stocks_row']); ?></td>
                                                                                    <td><?php echo e($stock['stocks_bin']); ?></td>
                                                                                    <td><?php echo e($stock->stocks_qty_on_hand); ?>

                                                                                    </td>
                                                                                    <td><?php echo e($stock->stocks_min_qty); ?></td>
                                                                                    <td><?php echo e($stock->stocks_max_qty); ?></td>
                                                                                </tr>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td><span class="text-info"><strong>No Logs
                                                                                            Found!</strong></span></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                                <td></td>
                                                                            <?php endif; ?>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userboms">
                            <div class="whitebox mb-4">
                                <div class="page-header mb-2">
                                    <h3>BOMs Details</h3>
                                    <a data-bs-toggle="modal" data-bs-target="#UploadSupBomModal"
                                        class="btn btn-primary float-end" style="cursor:pointer"> <i
                                            class="fa-solid fa-plus me-1"></i>Add new
                                    </a>
                                </div>
                                <div class="row">
                                    <div class="page-header">
                                        <h3>Asset Consuming Reference</h3>
                                        <hr>
                                    </div>
                                    <table class="display" id="SupplyBomList" width ="100%">
                                        <thead>
                                            <tr>
                                                <th width="3%">S#</th>
                                                <th width="13%">Asset</th>
                                                <th width="13%">Quantity</th>
                                                <th>Submitted By User</th>
                                                <th>Date Submitted</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_2 = true; $__currentLoopData = $assetPartSuppliesLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suppliesLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <?php
                                                    if (
                                                        isset($suppliesLog->part_supply_id) &&
                                                        $suppliesLog->part_supply_id != 'NULL'
                                                    ) {
                                                        if ($suppliesLog->asset_type == 'facility') {
                                                            $supplyLog = \App\Models\Facility::find(
                                                                $suppliesLog->asset_id,
                                                            );
                                                            $href = route('facilities.edit', $suppliesLog->asset_id);
                                                        } elseif ($suppliesLog->asset_type == 'equipment') {
                                                            $supplyLog = \App\Models\Equipment::find(
                                                                $suppliesLog->asset_id,
                                                            );
                                                            $href = route('equipments.edit', $suppliesLog->asset_id);
                                                        } elseif ($suppliesLog->asset_type == 'tools') {
                                                            $supplyLog = \App\Models\Tool::find($suppliesLog->asset_id);
                                                            $href = route('tools.edit', $suppliesLog->asset_id);
                                                        }
                                                    } else {
                                                        $supplyLog = '';
                                                        $href = 'javascript:void(0)';
                                                    }
                                                    if (
                                                        isset($suppliesLog->submitted_by) &&
                                                        $suppliesLog->submitted_by != 'NULL'
                                                    ) {
                                                        $submitted_by = \App\Models\User::find(
                                                            $suppliesLog->submitted_by,
                                                        );
                                                    }
                                                ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                    <td>
                                                        <?php if(isset($suppliesLog->part_supply_id) && $suppliesLog->part_supply_id != 'NULL'): ?>
                                                            <a href="<?php echo e($href); ?>"
                                                                target="_blank"><?php echo e($supplyLog->name ?? ''); ?>

                                                                (<?php echo e($supplyLog->code ?? ''); ?>)
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo e($suppliesLog->quantity ?? ''); ?>

                                                    </td>
                                                    <td>
                                                        <?php if(isset($suppliesLog->submitted_by) && $suppliesLog->submitted_by != 'NULL'): ?>
                                                            <a href="<?php echo e(route('users.show', $suppliesLog->submitted_by)); ?>"
                                                                class=""><?php echo e($submitted_by->name ?? ''); ?></a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($suppliesLog->updated_at ? \Carbon\Carbon::parse($suppliesLog->updated_at)->format('jS F, Y h:i:s A') : '--'); ?>

                                                    </td>
                                                    <td>
                                                        <a data-bs-toggle="modal"
                                                            data-bs-target="#EditBOMModal_<?php echo e($suppliesLog->id); ?>"
                                                            class="link-primary"><i
                                                                class="fa-regular fa-pen-to-square"></i></a>
                                                        <button type="button" class="link-danger"
                                                            onclick="delete_supplyparts('<?php echo e(route('supplyparts.delete', $suppliesLog->id)); ?>')"
                                                            data-id="<?php echo e($suppliesLog->id); ?>">
                                                            <i class="fa-solid fa-trash-can"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                                
                                                <div class="modal fade EditpartsModal"
                                                    id="EditBOMModal_<?php echo e($suppliesLog->id); ?>" data-bs-keyboard="false"
                                                    data-bs-backdrop="static">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <!-- Modal body -->
                                                            <div class="modal-body">
                                                                <h6 class="modal-title">Part Supply Assets</h6>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal"><i
                                                                        class="fa-solid fa-xmark"></i></button>
                                                                <div class="whitebox mb-4">
                                                                    <div class="mb-2">
                                                                        <label class="">Asset
                                                                        </label>
                                                                    </div>
                                                                    <div class="input-group mb-3">
                                                                        <input type="hidden" class="form-control"
                                                                            name="asset"
                                                                            id="asset_<?php echo e($suppliesLog->id); ?>"
                                                                            value="">
                                                                        <input type="hidden" class="form-control"
                                                                            name="asset_type"
                                                                            id="asset_type_<?php echo e($suppliesLog->id); ?>"
                                                                            value="">
                                                                        <input type="text"
                                                                            id="asset_msg_<?php echo e($suppliesLog->id); ?>"
                                                                            class="form-control <?php $__errorArgs = ['asset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            value="<?php echo e($supplyLog->name ?? ''); ?>(<?php echo e($supplyLog->code ?? ''); ?>)"
                                                                            readonly>
                                                                        <?php if($errors->has('asset')): ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($errors->first('asset')); ?></span>
                                                                        <?php endif; ?>
                                                                        <label for="asset_new_<?php echo e($suppliesLog->id); ?>"
                                                                            class="col-form-label text-md-end text-start">
                                                                        </label>
                                                                        <a data-bs-toggle="modal"
                                                                            id="asset_new_<?php echo e($suppliesLog->id); ?>"
                                                                            data-bs-target="#ShowAssetsModal_<?php echo e($suppliesLog->id); ?>"
                                                                            class="btn btn-primary float-end"
                                                                            style="cursor:pointer"> <i
                                                                                class="fa-solid fa-plus me-1"></i>
                                                                        </a>
                                                                    </div>
                                                                    <div class="mb-2"> <label for="quantity"
                                                                            class="col-form-label text-md-end text-start">Qty</label>
                                                                        <input type="number"
                                                                            id="quantity_<?php echo e($suppliesLog->id); ?>"
                                                                            name="quantity" class="form-control"
                                                                            value="<?php echo e($suppliesLog->quantity); ?>">
                                                                        <?php if($errors->has('quantity')): ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <button type="button"
                                                                    class="btn btn-primary mt-3 float-end save-parts-btn"
                                                                    data-log-id="<?php echo e($suppliesLog->id); ?>">Update</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><span class="text-info"><strong>No Logs
                                                                Found!</strong></span></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                    
                                    <?php $__currentLoopData = $assetPartSuppliesLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suppliesLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal fade ShowAssetsModal"
                                            id="ShowAssetsModal_<?php echo e($suppliesLog->id); ?>" tabindex="-1" role="dialog"
                                            aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                                <div class="modal-content">
                                                    <!-- Modal body -->
                                                    <div class="modal-body">
                                                        <h6 class="modal-title">Assets</h6>
                                                        
                                                        <button type="button" class="btn-close"
                                                            data-bs-dismiss="modal"><i
                                                                class="fa-solid fa-xmark"></i></button>
                                                        <table class="display table table-striped" id=""
                                                            width ="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th scope="col">Name</th>
                                                                    <th scope="col">Code</th>
                                                                    <th scope="col">Status</th>
                                                                    <th scope="col">Location</th>
                                                                    <th scope="col">Type</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $allfacilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr class="bom-row-modal" data-type="facility"
                                                                        data-id="<?php echo e($facility->id); ?>"
                                                                        data-parttableid="<?php echo e($suppliesLog->id); ?>"
                                                                        style="cursor: pointer">
                                                                        
                                                                        <td><?php echo e($facility->name); ?></td>
                                                                        <td><?php echo e($facility->code); ?></td>
                                                                        <td><?php echo e($facility->status == '1' ? 'Active' : 'Inactive'); ?>

                                                                        </td>
                                                                        <td>
                                                                            <?php if(
                                                                                $facility->assetAddress &&
                                                                                    $facility->assetAddress->parent_id &&
                                                                                    ($parentFacility = $allfacilities->where('id', $facility->assetAddress->parent_id)->first())): ?>
                                                                                <?php echo e($parentFacility->name); ?>

                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td style="color: brown">
                                                                            <?php echo e('Facility'); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $__currentLoopData = $allequipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr class="bom-row-modal" data-type="equipment"
                                                                        data-id="<?php echo e($equipment->id); ?>"
                                                                        data-parttableid="<?php echo e($suppliesLog->id); ?>"
                                                                        style="cursor: pointer">
                                                                        <td><?php echo e($equipment->name); ?></td>
                                                                        <td><?php echo e($equipment->code); ?></td>
                                                                        <td><?php echo e($equipment->status == '1' ? 'Active' : 'Inactive'); ?>

                                                                        </td>
                                                                        <td>
                                                                            <?php if(
                                                                                $equipment->assetAddress &&
                                                                                    $equipment->assetAddress->parent_id &&
                                                                                    ($parentFacility = $allfacilities->where('id', $equipment->assetAddress->parent_id)->first())): ?>
                                                                                <?php echo e($parentFacility->name); ?>

                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td style="color: orange">
                                                                            <?php echo e('Equipment'); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $__currentLoopData = $alltools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr class="bom-row-modal" data-type="tools"
                                                                        data-id="<?php echo e($tool->id); ?>"
                                                                        data-parttableid="<?php echo e($suppliesLog->id); ?>"
                                                                        style="cursor: pointer">
                                                                        <td><?php echo e($tool->name); ?></td>
                                                                        <td><?php echo e($tool->code); ?></td>
                                                                        <td><?php echo e($tool->status == '1' ? 'Active' : 'Inactive'); ?>

                                                                        </td>
                                                                        <td>
                                                                            <?php if(
                                                                                $tool->assetAddress &&
                                                                                    $tool->assetAddress->parent_id &&
                                                                                    ($parentFacility = $allfacilities->where('id', $tool->assetAddress->parent_id)->first())): ?>
                                                                                <?php echo e($parentFacility->name); ?>

                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td style="color: rgb(84, 9, 9)">
                                                                            <?php echo e('Tools'); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>

                        </div>
                        
                        <div class="tab-pane fade" id="userWarranties">
                            <div class="whitebox mb-4">
                                <div class="page-header mb-2">
                                    <h3>Warranty Details</h3>
                                    <a data-bs-toggle="modal" data-bs-target="#UploadWarrantyModal"
                                        class="btn btn-primary float-end" style="cursor:pointer"> <i
                                            class="fa-solid fa-plus me-1"></i>Add new
                                    </a>
                                </div>
                                <div class="row">
                                    <div class="page-header">
                                        <h3>Warranty Certificates </h3>
                                        <hr>
                                    </div>
                                    <table class="display" id="InventoryList" width ="100%">
                                        <thead>
                                            <tr>
                                                <th scope="col">S#</th>
                                                <th scope="col">Date Added</th>
                                                <th scope="col">Expiry Date</th>
                                                <th scope="col">Certificate Number</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_2 = true; $__currentLoopData = $assetWarranty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warranty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <tr>
                                                    <th scope="row" width="5%"><?php echo e($loop->iteration); ?></th>
                                                    <td width="35%">
                                                        <?php echo e(\Carbon\Carbon::parse($warranty['created_at'])->format('jS F, Y h:i A')); ?>

                                                    </td>
                                                    <td style="color: #990000" width="30%">
                                                        <?php if(isset($warranty['expiry_date'])): ?>
                                                            <?php echo e(\Carbon\Carbon::parse($warranty['expiry_date'])->format('jS F, Y')); ?>

                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td width="30%">
                                                        <?php echo e($warranty['certificate_number'] ?? ''); ?>

                                                    </td>
                                                    <td>
                                                        <a data-bs-toggle="modal"
                                                            data-bs-target="#EditwarrantyModal_<?php echo e($warranty->id); ?>"
                                                            class="link-primary"><i
                                                                class="fa-regular fa-pen-to-square"></i></a>

                                                        <button type="button" class="link-danger"
                                                            onclick="delete_supplywarranties('<?php echo e(route('supplywarranties.delete', $warranty->id)); ?>')"
                                                            data-id="<?php echo e($warranty->id); ?>">
                                                            <i class="fa-solid fa-trash-can"></i>
                                                        </button>
                                                    </td>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <td></td>
                                                <td></td>
                                                <td><span class="text-info"><strong>No Logs
                                                            Found!</strong></span></td>
                                                <td></td>
                                                <td></td>
                                            <?php endif; ?>

                                            
                                            <?php $__currentLoopData = $assetWarranty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warranty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="modal fade EditwarrantyModal"
                                                    id="EditwarrantyModal_<?php echo e($warranty->id); ?>" tabindex="-1"
                                                    role="dialog" aria-hidden="true" data-bs-keyboard="false"
                                                    data-bs-backdrop="static">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <!-- Modal body -->
                                                            <div class="modal-body">
                                                                <h6 class="modal-title">Warranty Certificate</h6>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal"><i
                                                                        class="fa-solid fa-xmark"></i></button>

                                                                <div class="item_name">
                                                                    <div class="whitebox mb-4">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="warranty_type_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Warranty
                                                                                    Type
                                                                                </label>
                                                                                <select
                                                                                    class="form-control <?php $__errorArgs = ['warranty_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    aria-label="Warranty Type"
                                                                                    id="warranty_type_<?php echo e($warranty->id); ?>"
                                                                                    name="warranty_type">
                                                                                    <option value="">--Select--
                                                                                    </option>
                                                                                    <option value="Basic"
                                                                                        <?php echo e($warranty->warranty_type == 'Basic' ? 'selected' : ''); ?>>
                                                                                        Basic</option>
                                                                                    <option value="Extended"
                                                                                        <?php echo e($warranty->warranty_type == 'Extended' ? 'selected' : ''); ?>>
                                                                                        Extended</option>
                                                                                </select>
                                                                                <?php if($errors->has('warranty_type')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('warranty_type')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <label for="provider_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Provider</label>
                                                                                <select
                                                                                    class="form-control <?php $__errorArgs = ['provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    aria-label="provider"
                                                                                    id="provider_<?php echo e($warranty->id); ?>"
                                                                                    name="provider">
                                                                                    <option value="">--Select
                                                                                        Business--</option>
                                                                                    <?php $__empty_2 = true; $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                        <option
                                                                                            value="<?php echo e($id); ?>"
                                                                                            <?php echo e($warranty->provider == $id ? 'selected' : ''); ?>>
                                                                                            <?php echo e($business); ?>

                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                                <?php if($errors->has('provider')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('provider')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row">

                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="warranty_usage_term_type2_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Warranty
                                                                                    Usage Term Type
                                                                                </label>
                                                                                <select
                                                                                    class="form-control <?php $__errorArgs = ['warranty_usage_term_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    aria-label="warranty_usage_term_type"
                                                                                    id="warranty_usage_term_type2_<?php echo e($warranty->id); ?>"
                                                                                    name="warranty_usage_term_type">
                                                                                    <option value="">--Select--
                                                                                    </option>
                                                                                    <option value="Date"
                                                                                        <?php echo e($warranty->warranty_usage_term_type == 'Date' ? 'selected' : ''); ?>>
                                                                                        Date</option>
                                                                                    <option value="Meter"
                                                                                        <?php echo e($warranty->warranty_usage_term_type == 'Meter' ? 'selected' : ''); ?>>
                                                                                        Meter reading</option>
                                                                                    <option value="Production"
                                                                                        <?php echo e($warranty->warranty_usage_term_type == 'Production' ? 'selected' : ''); ?>>
                                                                                        Production time</option>
                                                                                </select>
                                                                                <?php if($errors->has('warranty_usage_term_type')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('warranty_usage_term_type')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="expiry_date_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Expiry
                                                                                    Date</label>
                                                                                <input type="date"
                                                                                    class="form-control <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    id="expiry_date_<?php echo e($warranty->id); ?>"
                                                                                    name="expiry_date"
                                                                                    value="<?php echo e($warranty->expiry_date ?? ''); ?>">
                                                                                <?php if($errors->has('expiry_date')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('expiry_date')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row"
                                                                            id="meter_reading_fields2_<?php echo e($warranty->id); ?>">
                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="meter_reading_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Meter
                                                                                    Reading Value Limit
                                                                                </label>
                                                                                <input type="text"
                                                                                    id="meter_reading_<?php echo e($warranty->id); ?>"
                                                                                    name="meter_reading"
                                                                                    class="form-control <?php $__errorArgs = ['meter_reading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    placeholder="0.00"
                                                                                    value="<?php echo e($warranty->meter_reading ?? ''); ?>">
                                                                                <?php if($errors->has('meter_reading')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('meter_reading')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="meter_read_units_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Meter
                                                                                    Reading Units
                                                                                </label>
                                                                                <select
                                                                                    class="form-control <?php $__errorArgs = ['meter_read_units'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    aria-label="Meter read units"
                                                                                    id="meter_read_units_<?php echo e($warranty->id); ?>"
                                                                                    name="meter_read_units">
                                                                                    <option value="">--Select--
                                                                                    </option>
                                                                                    <?php $__currentLoopData = $MeterReadUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meterReadUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option
                                                                                            value="<?php echo e($meterReadUnit['id']); ?>"
                                                                                            <?php echo e($warranty->meter_reading_units == $meterReadUnit['id'] ? 'selected' : ''); ?>>
                                                                                            <?php echo e($meterReadUnit['name']); ?>

                                                                                            (<?php echo e($meterReadUnit['symbol']); ?>)
                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                                <?php if($errors->has('meter_read_units')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('meter_read_units')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="certificate_number_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Certificate
                                                                                    Number
                                                                                </label>
                                                                                <input type="text"
                                                                                    class="form-control <?php $__errorArgs = ['certificate_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    id="certificate_number_<?php echo e($warranty->id); ?>"
                                                                                    name="certificate_number"
                                                                                    value="<?php echo e($warranty['certificate_number'] ?? ''); ?>">
                                                                                <?php if($errors->has('certificate_number')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('certificate_number')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <label
                                                                                    for="warranty_description_<?php echo e($warranty->id); ?>"
                                                                                    class="col-form-label text-md-end text-start">Description</label>
                                                                                <textarea class="form-control <?php $__errorArgs = ['warranty_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="warranty_description"
                                                                                    id="warranty_description_<?php echo e($warranty->id); ?>" cols="48" rows="3"><?php echo e($warranty['description'] ?? ''); ?></textarea>
                                                                                <?php if($errors->has('warranty_description')): ?>
                                                                                    <span
                                                                                        class="text-danger"><?php echo e($errors->first('warranty_description')); ?></span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <button type="button"
                                                                    class="btn btn-primary mt-3 float-end save-warranty-btn"
                                                                    data-log-id="<?php echo e($warranty->id); ?>">Update</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userFiles">
                            <div class="item_name">
                                <div class="whitebox mb-4">
                                    <div class="page-header mb-2">
                                        <h3>Documents</h3>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <input type="file"
                                                class="form-control <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="files"
                                                name="files[]" multiple>
                                            <?php if($errors->has('files')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('files')); ?></span>
                                            <?php endif; ?>
                                            <span class="text-muted">*Supported file type: doc, docx,
                                                xlsx, xls, ppt, pptx, txt, pdf, jpg, jpeg, png, webp, gif</span>
                                        </div>
                                        <?php
                                            // print_r($assetFiles);
                                        ?>
                                        <table id="FacilityFilesList" class="display" width="100%">

                                            <thead>
                                                <tr>
                                                    <th scope="col">S#</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Description</th>
                                                    <th scope="col">Type</th>
                                                    
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            
                                            <tbody>
                                                <?php $__empty_3 = true; $__currentLoopData = $assetFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e($certificate->name); ?></td>
                                                        <td><?php echo e($certificate->description); ?></td>
                                                        <td><?php echo e($certificate->type); ?></td>
                                                        
                                                        <td><a href="<?php echo e(asset($certificate->url)); ?>"
                                                                class="btn btn-warning btn-sm" target="_blank"
                                                                title="View"><i class="bi bi-eye"></i></a>
                                                            <a data-bs-toggle="modal"
                                                                data-bs-target="#UploadFileModal_<?php echo e($certificate->af_id); ?>"
                                                                class="link-primary"><i
                                                                    class="fa-regular fa-pen-to-square"></i></a>
                                                            <button type="button" class="link-danger"
                                                                onclick="delete_savedocs('<?php echo e(route('supplydocs.delete', $certificate->af_id)); ?>')"
                                                                data-id="<?php echo e($certificate->af_id); ?>">
                                                                <i class="fa-solid fa-trash-can"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    
                                                    <div class="modal fade"
                                                        id="UploadFileModal_<?php echo e($certificate->af_id); ?>"
                                                        data-bs-keyboard="false" data-bs-backdrop="static">
                                                        <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <!-- Modal body -->
                                                                <div class="modal-body">
                                                                    <h6 class="modal-title">
                                                                        <?php echo e($supply->name); ?>

                                                                        Documents</h6>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"><i
                                                                            class="fa-solid fa-xmark"></i></button>
                                                                    
                                                                    <div class=""
                                                                        id="ajaxmsgModal<?php echo e($certificate->af_id); ?>">
                                                                    </div>
                                                                    <div class="whitebox mb-4">
                                                                        <div class="col-md-8">
                                                                            <label
                                                                                for="cert_name_<?php echo e($certificate->af_id); ?>"
                                                                                class="col-form-label text-md-end text-start">Name</label>
                                                                            <input type="text" class="form-control  "
                                                                                id="cert_name_<?php echo e($certificate->af_id); ?>"
                                                                                name="cert_name_<?php echo e($certificate->af_id); ?>"
                                                                                value="<?php echo e($certificate->name); ?>">
                                                                        </div>
                                                                        <div class="col-md-12">
                                                                            <label
                                                                                for="cert_description_<?php echo e($certificate->af_id); ?>"
                                                                                class="col-form-label text-md-end text-start">Description
                                                                            </label>
                                                                            <textarea class="form-control" id="cert_description_<?php echo e($certificate->af_id); ?>"
                                                                                name="cert_description_<?php echo e($certificate->af_id); ?>" rows="2"><?php echo e($certificate->description); ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <button type="button"
                                                                        class="btn btn-primary mt-3 float-end save-docs-btn"
                                                                        data-log-id="<?php echo e($certificate->af_id); ?>">Update</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                    <td></td>
                                                    <td></td>
                                                    
                                                    <td><span class="text-info"><strong>No Documents
                                                                Found!</strong></span></td>
                                                    
                                                    <td></td>
                                                    <td></td>
                                                <?php endif; ?>
                                            </tbody>
                                            
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal fade ShowtocksModal" id="ShowtocksModal" tabindex="-1" role="dialog"
                    aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog  modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Current Stock</h6>
                                <a data-bs-toggle="modal" data-bs-target="#UploadStocksModal"
                                    class="btn btn-primary float-end mt-2 mb-2" style="cursor:pointer"> <i
                                        class="fa-solid fa-plus me-1"></i>Add new
                                </a>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <table class="display table table-striped" id="" width ="100%">
                                    <thead>
                                        <tr>
                                            <th scope="col">S#</th>
                                            <th scope="col">Location</th>
                                            <th scope="col">Aisle</th>
                                            <th scope="col">Row</th>
                                            <th scope="col">Bin</th>
                                            <th scope="col">Qty on hand</th>
                                            <th scope="col">Min qty</th>
                                            <th scope="col">Max qty</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_3 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                            <?php
                                                // $stockLocation = json_decode($stock->location, true);
                                                // $stockQuantity = json_decode($stock->quantity, true);
                                            ?>
                                            <tr class="stock-row" data-id="<?php echo e($stock->id); ?>"
                                                style="cursor: pointer">
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <td>
                                                    <?php if(isset($facilities[$stock->parent_id])): ?>
                                                        <?php echo e($facilities[$stock->parent_id]); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($stock['stocks_aisle']); ?></td>
                                                <td><?php echo e($stock['stocks_row']); ?></td>
                                                <td><?php echo e($stock['stocks_bin']); ?></td>
                                                <td><?php echo e($stock->stocks_qty_on_hand); ?></td>
                                                <td><?php echo e($stock->stocks_min_qty); ?></td>
                                                <td><?php echo e($stock->stocks_max_qty); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><span class="text-info"><strong>No Logs
                                                        Found!</strong></span></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade ShowAssetsModal" id="ShowAssetsModal" tabindex="-1" role="dialog"
                    aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Assets</h6>
                                <a data-bs-toggle="modal" data-bs-target="#CreateAssetModal"
                                    class="btn btn-primary float-end mt-2 mb-2" style="cursor:pointer"> <i
                                        class="fa-solid fa-plus me-1"></i>Add new
                                </a>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <table class="display table table-striped" id="" width ="100%">
                                    <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Code</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Location</th>
                                            <th scope="col">Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allfacilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="bom-row" data-type="facility" data-id="<?php echo e($facility->id); ?>"
                                                style="cursor: pointer">
                                                
                                                <td><?php echo e($facility->name); ?></td>
                                                <td><?php echo e($facility->code); ?></td>
                                                <td><?php echo e($facility->status == '1' ? 'Active' : 'Inactive'); ?></td>
                                                <td>
                                                    <?php if(
                                                        $facility->assetAddress &&
                                                            $facility->assetAddress->parent_id &&
                                                            ($parentFacility = $allfacilities->where('id', $facility->assetAddress->parent_id)->first())): ?>
                                                        <?php echo e($parentFacility->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td style="color: brown">
                                                    <?php echo e('Facility'); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $allequipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="bom-row" data-type="equipment" data-id="<?php echo e($equipment->id); ?>"
                                                style="cursor: pointer">
                                                <td><?php echo e($equipment->name); ?></td>
                                                <td><?php echo e($equipment->code); ?></td>
                                                <td><?php echo e($equipment->status == '1' ? 'Active' : 'Inactive'); ?></td>
                                                <td>
                                                    <?php if(
                                                        $equipment->assetAddress &&
                                                            $equipment->assetAddress->parent_id &&
                                                            ($parentFacility = $allfacilities->where('id', $equipment->assetAddress->parent_id)->first())): ?>
                                                        <?php echo e($parentFacility->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td style="color: orange">
                                                    <?php echo e('Equipment'); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $alltools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="bom-row" data-type="tools" data-id="<?php echo e($tool->id); ?>"
                                                style="cursor: pointer">
                                                <td><?php echo e($tool->name); ?></td>
                                                <td><?php echo e($tool->code); ?></td>
                                                <td><?php echo e($tool->status == '1' ? 'Active' : 'Inactive'); ?></td>
                                                <td>
                                                    <?php if(
                                                        $tool->assetAddress &&
                                                            $tool->assetAddress->parent_id &&
                                                            ($parentFacility = $allfacilities->where('id', $tool->assetAddress->parent_id)->first())): ?>
                                                        <?php echo e($parentFacility->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td style="color: rgb(84, 9, 9)">
                                                    <?php echo e('Tools'); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade UploadStocksModal" id="UploadStocksModal" tabindex="-1" role="dialog"
                    aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Stock</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <div class="" id="ajaxStockModal"></div>
                                
                                <div class="whitebox mb-4">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="stocks_parent_facility"
                                                class="col-form-label text-md-end text-start">Location</label>
                                            <select
                                                class="form-control <?php $__errorArgs = ['stocks_parent_facility'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="stocks_parent_facility" id="stocks_parent_facility"
                                                name="stocks_parent_facility">
                                                <option value="">--None--</option>
                                                <?php $__empty_3 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                    <option value="<?php echo e($id); ?>"
                                                        <?php echo e(old('stocks_parent_facility') == $id ? 'selected' : ''); ?>>
                                                        <?php echo e($facility); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('stocks_parent_facility')): ?>
                                                <span id="stocks_parent_facility-error"
                                                    class="text-danger"><?php echo e($errors->first('stocks_parent_facility')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="initial_price"
                                                class="col-form-label text-md-end text-start">Initial price
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['initial_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="initial_price" name="initial_price" placeholder="0.00"
                                                value="<?php echo e(old('initial_price')); ?>">
                                        </div>

                                        <div class="col-md-4">
                                            <label for="stocks_aisle" class="col-form-label text-md-end text-start">Aisle
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['stocks_aisle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stocks_aisle" name="stocks_aisle"
                                                value="<?php echo e(old('stocks_aisle')); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="stocks_row" class="col-form-label text-md-end text-start">Row
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['stocks_row'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stocks_row" name="stocks_row" value="<?php echo e(old('stocks_row')); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="stocks_bin" class="col-form-label text-md-end text-start">Bin
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['stocks_bin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stocks_bin" name="stocks_bin" value="<?php echo e(old('stocks_bin')); ?>">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="stocks_qty_on_hand"
                                                class="col-form-label text-md-end text-start">Qty
                                                on hand
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['stocks_qty_on_hand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stocks_qty_on_hand" name="stocks_qty_on_hand"
                                                value="<?php echo e(old('stocks_qty_on_hand')); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="stocks_min_qty"
                                                class="col-form-label text-md-end text-start">Min
                                                qty
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['stocks_min_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stocks_min_qty" name="stocks_min_qty"
                                                value="<?php echo e(old('stocks_min_qty')); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="stocks_max_qty"
                                                class="col-form-label text-md-end text-start">Max
                                                qty
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['stocks_max_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stocks_max_qty" name="stocks_max_qty"
                                                value="<?php echo e(old('stocks_max_qty')); ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <input type="button" id="saveStocksBtn" class="btn btn-primary mt-3 float-end"
                                    value="Save">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="UploadInventoryModal" tabindex="-1" role="dialog" aria-hidden="true"
                    data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Asset Purchase Information</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <div class="" id="ajaxInventorymsg"></div>
                                <div class="whitebox mb-4">
                                    <div class="row">
                                        <div class="col-md-6 item_name">
                                            <label for="inventory_purchased_from"
                                                class="col-form-label text-md-end text-start">Purchased
                                                From</label>
                                            <select
                                                class="form-control <?php $__errorArgs = ['inventory_purchased_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="inventory_purchased_from" id="inventory_purchased_from"
                                                name="inventory_purchased_from">
                                                <option value="">--Select Business--</option>
                                                <?php $__empty_3 = true; $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                    <option value="<?php echo e($id); ?>"
                                                        <?php echo e(old('inventory_purchased_from') == $id ? 'selected' : ''); ?>>
                                                        <?php echo e($business); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('inventory_purchased_from')): ?>
                                                <span
                                                    class="text-danger"><?php echo e($errors->first('inventory_purchased_from')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6 item_name">
                                            <label for="inventory_purchase_currency"
                                                class="col-form-label text-md-end text-start">Purchase
                                                Currency</label>
                                            <select
                                                class="form-control <?php $__errorArgs = ['inventory_purchase_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="inventory_purchase_currency"
                                                id="inventory_purchase_currency" name="inventory_purchase_currency">
                                                <option value="">--None--</option>
                                                <?php $__empty_3 = true; $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $currenci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                    <option value="<?php echo e($id); ?>"
                                                        <?php echo e(old('inventory_purchase_currency') == $id ? 'selected' : ''); ?>>
                                                        <?php echo e($currenci); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('inventory_purchase_currency')): ?>
                                                <span
                                                    class="text-danger"><?php echo e($errors->first('inventory_purchase_currency')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="inventory_date_ordered"
                                                class="col-form-label text-md-end text-start">Date
                                                Ordered
                                            </label>
                                            <input type="date"
                                                class="form-control <?php $__errorArgs = ['inventory_date_ordered'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="inventory_date_ordered" name="inventory_date_ordered"
                                                value="<?php echo e(old('inventory_date_ordered')); ?>"
                                                min="<?php echo e(date('Y-m-d')); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inventory_date_received"
                                                class="col-form-label text-md-end text-start">Date
                                                Received
                                            </label>
                                            <input type="date"
                                                class="form-control <?php $__errorArgs = ['inventory_date_received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="inventory_date_received" name="inventory_date_received"
                                                value="<?php echo e(old('inventory_date_received')); ?>"
                                                min="<?php echo e(date('Y-m-d')); ?>">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">

                                            <label for="inventory_received_to_msg"
                                                class="col-form-label text-md-end text-start">Received
                                                To
                                            </label>
                                            <div class="input-group">
                                                <input type="hidden" class="form-control"
                                                    name="inventory_received_to" id="inventory_received_to"
                                                    value="">
                                                <input type="text" id="inventory_received_to_msg"
                                                    class="form-control <?php $__errorArgs = ['inventory_received_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="" readonly>
                                                <a data-bs-toggle="modal" data-bs-target="#ShowtocksModal"
                                                    class="btn btn-primary float-end" style="cursor:pointer"> <i
                                                        class="fa-solid fa-plus me-1"></i>
                                                </a>
                                                <?php if($errors->has('inventory_received_to')): ?>
                                                    <span id="inventory_received_to-error"
                                                        class="text-danger"><?php echo e($errors->first('inventory_received_to')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="inventory_quantity_received"
                                                class="col-form-label text-md-end text-start">Quantity
                                                Received
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['inventory_quantity_received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="inventory_quantity_received" name="inventory_quantity_received"
                                                value="<?php echo e(old('inventory_quantity_received')); ?>">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="inventory_purchase_price_per_unit"
                                                class="col-form-label text-md-end text-start">Purchase Price Per Unit
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['inventory_purchase_price_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="inventory_purchase_price_per_unit"
                                                name="inventory_purchase_price_per_unit"
                                                value="<?php echo e(old('inventory_purchase_price_per_unit')); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inventory_purchase_price_total"
                                                class="col-form-label text-md-end text-start">Purchase Price
                                                Total
                                            </label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['inventory_purchase_price_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="inventory_purchase_price_total"
                                                name="inventory_purchase_price_total"
                                                value="<?php echo e(old('inventory_purchase_price_total')); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="inventory_date_of_expiry"
                                                class="col-form-label text-md-end text-start">Date
                                                of Expiry
                                            </label>
                                            <input type="date"
                                                class="form-control <?php $__errorArgs = ['inventory_date_of_expiry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="inventory_date_of_expiry" name="inventory_date_of_expiry"
                                                value="<?php echo e(old('inventory_date_of_expiry')); ?>"
                                                min="<?php echo e(date('Y-m-d')); ?>">
                                        </div>
                                    </div>
                                </div>
                                <input type="button" id="saveInventoryBtn" class="btn btn-primary mt-3 float-end"
                                    value="Save">

                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade UploadWarrantyModal" id="UploadWarrantyModal" tabindex="-1" role="dialog"
                    aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Warranty Certificate</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <div class="" id="ajaxWarrantymsg"></div>
                                <div class="item_name">
                                    <div class="whitebox mb-4">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="warranty_type"
                                                    class="col-form-label text-md-end text-start">Warranty Type
                                                </label>
                                                <select class="form-control <?php $__errorArgs = ['warranty_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Warranty Type" id="warranty_type"
                                                    name="warranty_type">
                                                    <option value="">--Select--</option>
                                                    <option value="Basic">
                                                        Basic</option>
                                                    <option value="Extended">
                                                        Extended</option>
                                                </select>
                                                <?php if($errors->has('warranty_type')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('warranty_type')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="provider"
                                                    class="col-form-label text-md-end text-start">Provider</label>
                                                <select class="form-control <?php $__errorArgs = ['provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="provider" id="provider" name="provider">
                                                    <option value="">--Select Business--</option>
                                                    <?php $__empty_3 = true; $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                        <option value="<?php echo e($id); ?>">
                                                            <?php echo e($business); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('provider')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('provider')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="warranty_usage_term_type1"
                                                    class="col-form-label text-md-end text-start">Warranty Usage Term Type
                                                </label>
                                                <select
                                                    class="form-control <?php $__errorArgs = ['warranty_usage_term_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="warranty_usage_term_type" id="warranty_usage_term_type1"
                                                    name="warranty_usage_term_type">
                                                    <option value="">--Select--</option>
                                                    <option value="Date">
                                                        Date</option>
                                                    <option value="Meter">
                                                        Meter reading</option>
                                                    <option value="Production">
                                                        Production time</option>
                                                </select>
                                                <?php if($errors->has('warranty_usage_term_type')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('warranty_usage_term_type')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="expiry_date"
                                                    class="col-form-label text-md-end text-start">Expiry
                                                    Date</label>
                                                <input type="date"
                                                    class="form-control <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="expiry_date" name="expiry_date" value="">
                                                <?php if($errors->has('expiry_date')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('expiry_date')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row" id="meter_reading_fields1">
                                            <div class="col-md-6">
                                                <label for="meter_reading"
                                                    class="col-form-label text-md-end text-start">Meter
                                                    Reading Value Limit
                                                </label>
                                                <input type="text" id="meter_reading" name="meter_reading"
                                                    class="form-control <?php $__errorArgs = ['meter_reading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="0.00" value="">
                                                <?php if($errors->has('meter_reading')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('meter_reading')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="meter_read_units"
                                                    class="col-form-label text-md-end text-start">Meter
                                                    Reading Units
                                                </label>
                                                <select
                                                    class="form-control <?php $__errorArgs = ['meter_read_units'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Meter read units" id="meter_read_units"
                                                    name="meter_read_units">
                                                    <option value="">--Select--</option>
                                                    <?php $__currentLoopData = $MeterReadUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meterReadUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($meterReadUnit['id']); ?>">
                                                            <?php echo e($meterReadUnit['name']); ?>

                                                            (<?php echo e($meterReadUnit['symbol']); ?>)
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('meter_read_units')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('meter_read_units')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="certificate_number"
                                                    class="col-form-label text-md-end text-start">Certificate Number
                                                </label>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['certificate_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="certificate_number" name="certificate_number" value="">
                                                <?php if($errors->has('certificate_number')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('certificate_number')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="warranty_description"
                                                    class="col-form-label text-md-end text-start">Description</label>
                                                <textarea class="form-control <?php $__errorArgs = ['warranty_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="warranty_description"
                                                    id="warranty_description" cols="48" rows="3"></textarea>
                                                <?php if($errors->has('warranty_description')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('warranty_description')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="button" id="saveWarrantyBtn" class="btn btn-primary mt-3 float-end"
                                    value="Save">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade UploadUserModal" id="UploadUserModal" tabindex="-1" role="dialog"
                    aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Personnel</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <div class="" id="ajaxUsermsg"></div>
                                <div class="whitebox mb-4">
                                    <div class="row">
                                        <?php if($errors->has('personnel')): ?>
                                            <span id="personnel"
                                                class="text-danger"><?php echo e($errors->first('personnel')); ?></span>
                                        <?php endif; ?>
                                        <span id="personnel-error" class="text-warning"></span>
                                        <div class="col-md-6">
                                            <label for="personnel" class="col-form-label text-md-end text-start">User
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['personnel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="personnel" id="personnel" name="personnel">
                                                <option value="">Select</option>
                                                <?php $__empty_4 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_4 = false; ?>
                                                    <option value="<?php echo e($id); ?>"
                                                        <?php echo e(old('personnel') == $id ? 'selected' : ''); ?>>
                                                        <?php echo e($user); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_4): ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <input type="button" id="saveUserBtn" class="btn btn-primary mt-3 float-end"
                                    value="Save">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade UploadSupBomModal" id="UploadSupBomModal" tabindex="-1" role="dialog"
                    aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h6 class="modal-title">Part Supply Assets</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <div class="" id="ajaxbommsg"></div>
                                <div class="whitebox mb-4">
                                    <div class="mb-2">
                                        <label class="">Asset
                                        </label>
                                    </div>
                                    <div class="input-group mb-3">
                                        <input type="hidden" class="form-control" name="asset" id="asset"
                                            value="">
                                        <input type="hidden" class="form-control" name="asset_type" id="asset_type"
                                            value="">
                                        <input type="text" id="asset_msg"
                                            class="form-control <?php $__errorArgs = ['asset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                            readonly>
                                        <?php if($errors->has('asset')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('asset')); ?></span>
                                        <?php endif; ?>
                                        <label for="asset_new" class="col-form-label text-md-end text-start">
                                        </label>
                                        <a data-bs-toggle="modal" id="asset_new" data-bs-target="#ShowAssetsModal"
                                            class="btn btn-primary float-end" style="cursor:pointer"> <i
                                                class="fa-solid fa-plus me-1"></i>
                                        </a>
                                    </div>
                                    <div class="mb-2">
                                        <label for="quantity" class="col-form-label text-md-end text-start">Qty</label>
                                        <input type="number" id="quantity" name="quantity" class="form-control"
                                            value="<?php echo e(old('quantity')); ?>">
                                        <?php if($errors->has('quantity')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <input type="button" id="savesupBomBtn" class="btn btn-primary mt-3 float-end"
                                    value="Save">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade CreateAssetModal" id="CreateAssetModal" data-bs-keyboard="false"
                    data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-body">
                                <h6 class="modal-title">Create New Asset</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"><i
                                        class="fa-solid fa-xmark"></i></button>
                                <div class="row align-items-center justify-content-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-facility', 'create-facility', 'edit-facility', 'delete-facility'])): ?>
                                        <div class="col-md-6">
                                            <a href="<?php echo e(route('facilities.create')); ?>" class="border-purple"
                                                target="_blank">
                                                <div class="d-flex">
                                                    <span class="me-2"><img
                                                            src="<?php echo e(asset('public/img/location_icon.png')); ?>"
                                                            alt="img" class="img-fluid"></span>
                                                    <span class="mt-2">Locations or Facilities</span>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-equipment', 'create-equipment', 'edit-equipment', 'delete-equipment'])): ?>
                                        <div class="col-md-6">

                                            <a href="<?php echo e(route('equipments.create')); ?>" class="border-purple"
                                                target="_blank">
                                                <div class="d-flex">
                                                    <span class="me-2"><img
                                                            src="<?php echo e(asset('public/img/machine_icon.png')); ?>"
                                                            alt="img" class="img-fluid"></span>
                                                    <span class="mt-2">Equipment or Machines</span>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-tools', 'create-tools', 'edit-tools', 'delete-tools'])): ?>
                                        <div class="col-md-6">
                                            <a href="<?php echo e(route('tools.create')); ?>" class="border-purple" target="_blank">
                                                <div class="d-flex">
                                                    <span class="me-2"><img
                                                            src="<?php echo e(asset('public/img/tool_icon.png')); ?>" alt="img"
                                                            class="img-fluid"></span>
                                                    <span class="mt-4">Tools</span>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </form>
    </div>



    <?php $__env->startPush('javascript'); ?>
        <script>
            function getRandomInt(min, max) {
                return Math.floor(Math.random() * (max - min + 1)) + min;
            }
            $(document).ready(function() {
                var i = 1;
                var newName = 'New Parts And Supplies #';
                var newCode = 'S' + getRandomInt(1000, 9999);
                if ($('#name').val() == '') {
                    $('#name').val(newName + newCode);
                }
                if ($('#code').val() == '') {
                    $('#code').val(newCode);
                }
                i = i++;
            });
        </script>
        <script>
            $('#inventory_purchase_currency').select2({
                dropdownParent: $('#UploadInventoryModal .modal-content')
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#saveStocksBtn').click(function(e) {
                    e.preventDefault();
                    var formData = $('#supplyUpdateForm').serialize();
                    $.ajax({
                        url: '<?php echo e(route('save.stocks')); ?>',
                        method: 'PUT',
                        data: formData,
                        success: function(response) {
                            // Display success message
                            $('#stocks_parent_facility').removeClass('is-invalid');
                            $('#stocks_parent_facility-error').html('');
                            $('#ajaxStockModal').html('<div class="alert alert-success">' + response
                                .message + '</div>');
                            setTimeout(function() {
                                $('#UploadStocksModal').modal('hide');
                                // Reload the page after 2 seconds
                                setTimeout(function() {
                                    location.reload();
                                }, 2000);
                            }, 500);
                        },
                        error: function(xhr, status, error) {
                            var errors = xhr.responseJSON.errors;
                            $.each(errors, function(field, messages) {
                                $('#' + field).addClass('is-invalid');
                                $('#ajaxStockModal').html(
                                    '<div class="alert alert-danger">' +
                                    messages[0] + '</div>'
                                );
                            });
                            // $('#ajaxStockModal').html(
                            //     '<div class="alert alert-danger"> Location is required</div>');
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                // Add click event listener to each row
                $('.stock-row').click(function() {
                    // Extract the data-id attribute value
                    var stockId = $(this).data('id');
                    $('#ShowtocksModal').modal('hide');
                    // Populate the input field with the extracted value
                    $('#inventory_received_to').val(stockId);
                    $.ajax({
                        url: '<?php echo e(route('getSupplyName')); ?>',
                        type: 'GET',
                        data: {
                            stockId: stockId
                        },
                        success: function(response) {
                            $('#inventory_received_to_msg').val(response.supplyName);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                // Add click event listener to each row
                $('.bom-row').click(function() {
                    // Extract the data-id attribute value
                    var bomId = $(this).data('id');
                    var bomType = $(this).data('type');
                    $('#ShowAssetsModal').modal('hide');
                    // Populate the input field with the extracted value
                    $('#asset').val(bomId);
                    $('#asset_type').val(bomType);
                    $.ajax({
                        url: '<?php echo e(route('getAssetName')); ?>',
                        type: 'GET',
                        data: {
                            bomId: bomId,
                            bomType: bomType
                        },
                        success: function(response) {
                            $('#asset_msg').val(response.assetName);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#savesupBomBtn').click(function(e) {
                    e.preventDefault();
                    var formData = $('#supplyUpdateForm').serialize();
                    $.ajax({
                        url: '<?php echo e(route('save.suppliesbom')); ?>',
                        method: 'PUT',
                        data: formData,
                        success: function(response) {
                            // Display success message
                            $('#asset_msg').removeClass('is-invalid');
                            $('#asset-error').html('');
                            $('#ajaxbommsg').html('<div class="alert alert-success">' +
                                response
                                .message + '</div>');
                            setTimeout(function() {
                                $('#UploadSupBomModal').modal('hide');
                                // Reload the page after 2 seconds
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            var errors = xhr.responseJSON.errors;
                            $.each(errors, function(field, messages) {
                                $('#asset_msg').addClass('is-invalid');
                                $('#' + field + '-error').html(
                                    '<span class="invalid-feedback">' + messages[0] +
                                    '</span>');
                                $('#ajaxbommsg').html(
                                    '<div class="alert alert-danger"> ' + messages[0] +
                                    ' </div>');
                            });
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                // Function to calculate and update the total purchase price
                function updateTotalPrice() {
                    var inventory_quantity_received = parseFloat($('#inventory_quantity_received').val());
                    var inventory_purchase_price_per_unit = parseFloat($('#inventory_purchase_price_per_unit').val());
                    var totalPrice = isNaN(inventory_quantity_received) || isNaN(inventory_purchase_price_per_unit) ?
                        0 : (inventory_quantity_received * inventory_purchase_price_per_unit);
                    $('#inventory_purchase_price_total').val(totalPrice.toFixed(
                        2)); // Assuming you want to display the total with 2 decimal places
                }

                // Event listener for the change event on quantity received field
                $('input[id^="inventory_quantity_received"]').on('input', function() {
                    updateTotalPrice();
                });

                // Event listener for the change event on purchase price per unit field
                $('input[id^="inventory_purchase_price_per_unit"]').on('input', function() {
                    updateTotalPrice();
                });

                // Function to validate and set min date for "Date Received" field
                function validateDateReceive() {
                    var dateOrdered = new Date($('#inventory_date_ordered').val());
                    var dateReceivedInput = $('#inventory_date_received');
                    var dateReceived = new Date(dateReceivedInput.val());

                    // Validate that "Date Received" is after "Date Ordered"
                    if (dateReceived < dateOrdered) {
                        dateReceivedInput.val(''); // Clear the value if it's before "Date Ordered"
                        alert('Date Received must be after Date Ordered.');
                    }
                }

                // Event listener for the change event on "Date Ordered" field
                $('input[id^="inventory_date_ordered"]').on('change', function() {
                    validateDateReceive();
                });

                // Event listener for the change event on "Date Received" field
                $('input[id^="inventory_date_received"]').on('change', function() {
                    validateDateReceive();
                });
                $('#saveInventoryBtn').click(function(e) {
                    e.preventDefault();
                    var formData = $('#supplyUpdateForm').serialize();
                    $.ajax({
                        url: '<?php echo e(route('save.inventories')); ?>',
                        method: 'PUT',
                        data: formData,
                        success: function(response) {
                            // Display success message
                            $('#inventory_received_to_msg').removeClass('is-invalid');
                            $('#inventory_received_to-error').html('');
                            $('#ajaxInventorymsg').html('<div class="alert alert-success">' +
                                response
                                .message + '</div>');
                            setTimeout(function() {
                                $('#UploadInventoryModal').modal('hide');
                                // Reload the page after 2 seconds
                                setTimeout(function() {
                                    location.reload();
                                }, 2000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            var errors = xhr.responseJSON.errors;
                            $.each(errors, function(field, messages) {
                                $('#inventory_received_to_msg').addClass('is-invalid');
                                $('#' + field + '-error').html(
                                    '<span class="invalid-feedback">' + messages[0] +
                                    '</span>');
                            });
                            $('#ajaxInventorymsg').html(
                                '<div class="alert alert-danger"> Location is required </div>');
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#saveWarrantyBtn').click(function(e) {
                    e.preventDefault();
                    var formData = $('#supplyUpdateForm').serialize();
                    $.ajax({
                        url: '<?php echo e(route('save.warranties')); ?>',
                        method: 'PUT',
                        data: formData,
                        success: function(response) {
                            // Display success message
                            $('#ajaxWarrantymsg').html('<div class="alert alert-success">' +
                                response
                                .message + '</div>');
                            setTimeout(function() {
                                $('#UploadWarrantyModal').modal('hide');
                                // Reload the page after 2 seconds
                                setTimeout(function() {
                                    location.reload();
                                }, 2000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            var errors = xhr.responseJSON.errors;
                            $.each(errors, function(field, messages) {});
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#saveUserBtn').click(function(e) {
                    e.preventDefault();
                    var formData = $('#supplyUpdateForm').serialize();
                    $.ajax({
                        url: '<?php echo e(route('save.users')); ?>',
                        method: 'PUT',
                        data: formData,
                        success: function(response) {
                            // Display success message
                            $('#personnel-error').html('');
                            $('#personnel').removeClass('is-invalid');
                            $('#ajaxUsermsg').html('<div class="alert alert-success">' +
                                response
                                .message + '</div>');
                            setTimeout(function() {
                                $('#UploadUserModal').modal('hide');
                                // Reload the page after 2 seconds
                                setTimeout(function() {
                                    location.reload();
                                }, 2000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            $('#personnel-error').html('');
                            $('#personnel').addClass('is-invalid');
                            $.each(xhr.responseJSON.errors, function(key, value) {
                                $('#personnel-error').append(
                                    '<div class="alert alert-danger">' + value + '</div'
                                );
                            });
                        },
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#warranty_usage_term_type1').change(function() {
                    var selectedOption = $(this).val();
                    if (selectedOption === 'Date' || selectedOption === '') {
                        $('#meter_reading_fields1').hide();
                    } else {
                        $('#meter_reading_fields1').show();
                    }
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#warranty_usage_term_type2').change(function() {
                    var selectedOption = $(this).val();
                    if (selectedOption === 'Date' || selectedOption === '') {
                        $('#meter_reading_fields2').hide();
                    } else {
                        $('#meter_reading_fields2').show();
                    }
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('.save-docs-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var docsName = $('#cert_name_' + logId).val();
                    var docsDescription = $('#cert_description_' + logId).val();

                    var url = "<?php echo e(route('save.supplydocs')); ?>";
                    var data = {
                        log_id: logId,
                        docsName: docsName,
                        docsDescription: docsDescription,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#UploadFileModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_savedocs(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',

                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>

        <script>
            $(document).ready(function() {
                $('.save-warranty-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var warranty_type = $('#warranty_type_' + logId).val();
                    var provider = $('#provider_' + logId).val();
                    var warranty_usage_term_type = $('#warranty_usage_term_type2_' + logId).val();
                    var expiry_date = $('#expiry_date_' + logId).val();
                    var meter_reading = $('#meter_reading_' + logId).val();
                    var meter_read_units = $('#meter_read_units_' + logId).val();
                    var certificate_number = $('#certificate_number_' + logId).val();
                    var warranty_description = $('#warranty_description_' + logId).val();

                    var url = "<?php echo e(route('save.supplywarranties')); ?>";
                    var data = {
                        log_id: logId,
                        warranty_type: warranty_type,
                        provider: provider,
                        warranty_usage_term_type: warranty_usage_term_type,
                        expiry_date: expiry_date,
                        meter_reading: meter_reading,
                        meter_read_units: meter_read_units,
                        certificate_number: certificate_number,
                        warranty_description: warranty_description,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#EditwarrantyModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_supplywarranties(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',

                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
        <script>
            $(document).ready(function() {
                // Add click event listener to each row
                $('.bom-row-modal').click(function() {
                    // Extract the data-id attribute value
                    var bomId = $(this).data('id');
                    var bomType = $(this).data('type');
                    var parttableid = $(this).data('parttableid');

                    $('#ShowAssetsModal_' + parttableid).modal('hide');
                    // Populate the input field with the extracted value
                    $('#asset_' + parttableid).val(bomId);
                    $('#asset_type_' + parttableid).val(bomType);
                    $.ajax({
                        url: '<?php echo e(route('getAssetName')); ?>',
                        type: 'GET',
                        data: {
                            bomId: bomId,
                            bomType: bomType
                        },
                        success: function(response) {
                            $('#asset_msg_' + parttableid).val(response.assetName);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                // Add click event listener to each row
                $('.inventories-row-modal').click(function() {
                    // Extract the data-id attribute value
                    var stockId = $(this).data('id');
                    var tableid = $(this).data('tableid');

                    $('#ShowtocksModal_' + tableid).modal('hide');
                    // Populate the input field with the extracted value
                    $('#inventory_received_to_' + tableid).val(stockId);

                    $.ajax({
                        url: '<?php echo e(route('getSupplyName')); ?>',
                        type: 'GET',
                        data: {
                            stockId: stockId,
                        },
                        success: function(response) {
                            $('#inventory_received_to_msg_' + tableid).val(response.supplyName);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('.save-parts-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var asset = $('#asset_' + logId).val();
                    var asset_type = $('#asset_type_' + logId).val();
                    var quantity = $('#quantity_' + logId).val();

                    var url = "<?php echo e(route('save.supplyparts')); ?>";
                    var data = {
                        log_id: logId,
                        asset: asset,
                        asset_type: asset_type,
                        quantity: quantity,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#EditBOMModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_supplyparts(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
        <script>
            $(document).ready(function() {

                $('.save-stocks-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var ParentFaciliy = $('#stocks_parent_facility_' + logId).val();
                    var initial_price = $('#initial_price_' + logId).val();
                    var stocks_aisle = $('#stocks_aisle_' + logId).val();
                    var stocks_row = $('#stocks_row_' + logId).val();
                    var stocks_bin = $('#stocks_bin_' + logId).val();
                    var stocks_qty_on_hand = $('#stocks_qty_on_hand_' + logId).val();
                    var stocks_min_qty = $('#stocks_min_qty_' + logId).val();
                    var stocks_max_qty = $('#stocks_max_qty_' + logId).val();
                    var assetID = $('#AssetID').val();

                    var url = "<?php echo e(route('save.supplystocks')); ?>";
                    var data = {
                        log_id: logId,
                        assetID: assetID,
                        ParentFaciliy: ParentFaciliy,
                        initial_price: initial_price,
                        stocks_aisle: stocks_aisle,
                        stocks_row: stocks_row,
                        stocks_bin: stocks_bin,
                        stocks_qty_on_hand: stocks_qty_on_hand,
                        stocks_min_qty: stocks_min_qty,
                        stocks_max_qty: stocks_max_qty,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#UpdateStocksModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_stockdetails(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
        <script>
            $(document).ready(function() {
                // Function to calculate and update the total purchase price
                function updateTotalPrice(logId) {
                    var inventory_quantity_received = parseFloat($('#inventory_quantity_received_' + logId).val());
                    var inventory_purchase_price_per_unit = parseFloat($('#inventory_purchase_price_per_unit_' + logId)
                        .val());
                    var totalPrice = isNaN(inventory_quantity_received) || isNaN(inventory_purchase_price_per_unit) ?
                        0 : (inventory_quantity_received * inventory_purchase_price_per_unit);
                    $('#inventory_purchase_price_total_' + logId).val(totalPrice.toFixed(
                        2)); // Assuming you want to display the total with 2 decimal places
                }

                // Event listener for the change event on quantity received field
                $('input[id^="inventory_quantity_received_"]').on('input', function() {
                    var logId = $(this).attr('id').split('_').pop();
                    updateTotalPrice(logId);
                });

                // Event listener for the change event on purchase price per unit field
                $('input[id^="inventory_purchase_price_per_unit_"]').on('input', function() {
                    var logId = $(this).attr('id').split('_').pop();
                    updateTotalPrice(logId);
                });
                // Function to validate and set min date for "Date Received" field
                function validateDateReceived(logId) {
                    var dateOrdered = new Date($('#inventory_date_ordered_' + logId).val());
                    var dateReceivedInput = $('#inventory_date_received_' + logId);
                    var dateReceived = new Date(dateReceivedInput.val());

                    // Validate that "Date Received" is after "Date Ordered"
                    if (dateReceived < dateOrdered) {
                        dateReceivedInput.val(''); // Clear the value if it's before "Date Ordered"
                        alert('Date Received must be after Date Ordered.');
                    }
                }

                // Event listener for the change event on "Date Ordered" field
                $('input[id^="inventory_date_ordered_"]').on('change', function() {
                    var logId = $(this).attr('id').split('_').pop();
                    validateDateReceived(logId);
                });

                // Event listener for the change event on "Date Received" field
                $('input[id^="inventory_date_received_"]').on('change', function() {
                    var logId = $(this).attr('id').split('_').pop();
                    validateDateReceived(logId);
                });
                $('.save-inventories-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var assetID = $('#AssetID').val();
                    var inventory_purchased_from = $('#inventory_purchased_from_' + logId).val();
                    var inventory_purchase_currency = $('#inventory_purchase_currency_' + logId).val();
                    var inventory_date_ordered = $('#inventory_date_ordered_' + logId).val();
                    var inventory_date_received = $('#inventory_date_received_' + logId).val();
                    var inventory_received_to = $('#inventory_received_to_' + logId).val();
                    var inventory_quantity_received = $('#inventory_quantity_received_' + logId).val();
                    var inventory_purchase_price_per_unit = $('#inventory_purchase_price_per_unit_' + logId)
                        .val();
                    var inventory_purchase_price_total = $('#inventory_purchase_price_total_' + logId).val();
                    var inventory_date_of_expiry = $('#inventory_date_of_expiry_' + logId).val();

                    var url = "<?php echo e(route('save.supplyinventories')); ?>";
                    var data = {
                        log_id: logId,
                        assetID: assetID,
                        inventory_purchased_from: inventory_purchased_from,
                        inventory_purchase_currency: inventory_purchase_currency,
                        inventory_date_ordered: inventory_date_ordered,
                        inventory_date_received: inventory_date_received,
                        inventory_received_to: inventory_received_to,
                        inventory_quantity_received: inventory_quantity_received,
                        inventory_purchase_price_per_unit: inventory_purchase_price_per_unit,
                        inventory_purchase_price_total: inventory_purchase_price_total,
                        inventory_date_of_expiry: inventory_date_of_expiry,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#UpdateInventoryModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_inventoriesdetails(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/busfaypa/public_html/webiconnect.net/dev/pms/resources/views/supplies/edit.blade.php ENDPATH**/ ?>