<?php $__env->startSection('content'); ?>
    <?php
        $current_date_time = \Carbon\Carbon::now();
        $assetAddress = $facility->assetAddress;
        $address = json_decode($assetAddress['address'], true);
        $assetGeneralInfo = $facility->assetGeneralInfo;
        $assetPartSuppliesLog = $facility->assetPartSuppliesLog;
        $meterReadings = $facility->meterReadings;
        $assetFiles = $facility->assetFiles;
        // echo '<pre>';
        // print_r($facility);
        // print_r($assetAddress);
        // echo '</pre>';
        
        // echo $address['address'];
        // print_r($facility->assetGeneralInfo);
    ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <form action="<?php echo e(route('facilities.update', $facility->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="wrapper">
                <div class="status_bar">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <div class="page-header">
                                <h3> Edit Facility <?php if(!empty($facility->id)): ?>
                                        <span class="text-info"> <a href="javascript:void(0);"
                                                class="btn btn-info btn-sm"><?php echo e($facility->name); ?>

                                                (<?php echo e($facility->code); ?>)</a><span>
                                    <?php endif; ?>
                                </h3>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="float-end">
                                <div class="status_area">
                                    <ul>
                                        <li>
                                            <h3>Status</h3>
                                        </li>
                                        <li>
                                            <select class="form-select" aria-label="Default select example" name="status">
                                                <option value="1" <?php echo e($facility->status == 1 ? 'selected' : ''); ?>>Active
                                                </option>
                                                <option value="0" <?php echo e($facility->status == 0 ? 'selected' : ''); ?>>
                                                    Disable
                                                </option>
                                            </select>
                                        </li>
                                        <li>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fa-solid fa-floppy-disk"></i> Publish
                                            </button>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('facilities.index')); ?>" class="btn btn-primary float-end">
                                                <i class="fa-solid fa-list me-1"></i>All Facilities
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="nav_tab_area">
                    <ul class="nav nav-tabs mb-3" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#userBasic">Basic</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userGeneral">General</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userContact">Parts/BOM</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userCareer">Metering/Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#userFiles">Files</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="userBasic">

                            <div class="whitebox mb-4">
                                <div class="page-header mb-2">
                                    <h3>Basic Details</h3>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="name" class="col-form-label text-md-end text-start">Facility
                                            name</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="name" name="name" value="<?php echo e($facility->name); ?>">
                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="code" class="col-form-label text-md-end text-start">Code</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="code" name="code" value="<?php echo e($facility->code); ?>">
                                        <?php if($errors->has('code')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="category_id" class="col-form-label text-md-end text-start">Category
                                        </label>
                                        <select class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Category" id="category_id" name="category_id">
                                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($id); ?>"
                                                    <?php echo e($facility->category_id == $id ? 'selected' : ''); ?>>
                                                    <?php echo e($category); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('category_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('category_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="description"
                                            class="col-form-label text-md-end text-start">Description</label>
                                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description"
                                            cols="48" rows="6"><?php echo $facility->description; ?></textarea>
                                        <?php if($errors->has('description')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userGeneral">
                            <div class="item_name">

                                <div class="whitebox mb-4">
                                    <div class="page-header mb-2">
                                        <h3>Location</h3>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 mb-2">
                                            <input type="radio" class="<?php $__errorArgs = ['old_faci_chkbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="old_faci_chkbox" name="faci_chkbox" value="1"
                                                <?php echo e($assetAddress['has_parent'] == 1 ? 'checked' : ''); ?>

                                                onclick="toggleDropdown()">
                                            <label for="old_faci_chkbox"
                                                class="col-form-label text-md-end text-start">This
                                                facility is a part of:</label>
                                        </div>
                                        <div class="col-md-8 mb-2">
                                            <input type="radio" class="<?php $__errorArgs = ['new_faci_chkbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="new_faci_chkbox" name="faci_chkbox" value="0"
                                                <?php echo e($assetAddress['has_parent'] == 0 ? 'checked' : ''); ?>

                                                onclick="toggleNewAddr()">
                                            <label for="new_faci_chkbox"
                                                class="col-form-label text-md-end text-start">This
                                                facility is not part of another location, and is located at:</label>
                                        </div>
                                        <div class="col-md-6 item_name old_faci_addr" id="old_faci_addr"
                                            style="display: none;">
                                            <label for="parent_id" class="col-form-label text-md-end text-start">Select
                                                Parent
                                                facility</label>
                                            <select class="form-control <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Parent facility" id="parent_id" name="parent_id">
                                                <option value="">--None--</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $faciliti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php if($facility->id != $id): ?>
                                                        <option value="<?php echo e($id); ?>"
                                                            <?php echo e($assetAddress['parent_id'] == $id ? 'selected' : ''); ?>>
                                                            <?php echo e($faciliti); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            <div class="new_address_field" id="new_address_field" style="display: none;">
                                                <textarea name="add_address" id="add_address" cols="48" rows="2"><?php echo e($assetAddress['add_address']); ?></textarea>
                                            </div>
                                            <span id="parent_address_warning" class="text-warning"
                                                style="display: none;">No address given in parent facility</span>
                                            <?php if($errors->has('parent_id')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('parent_id')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <span id="address_success" class="text-success col-md-6"
                                            style="display: none;"></span>
                                    </div>
                                    <div class="row item_name faci_new_addr" id="faci_new_addr" style="display: none;">
                                        <div class="col-md-12">
                                            <label for="address"
                                                class="col-form-label text-md-end text-start">Address</label>
                                            <textarea class="form-control <?php $__errorArgs = ['contact.address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contact[address]" id="address"
                                                cols="48" rows="2"><?php echo e(isset($address['address']) ? $address['address'] : ''); ?></textarea>
                                            <?php if($errors->has('contact.address')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('contact.address')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="country-dd"
                                                    class="col-form-label text-md-end text-start">Country</label>
                                                <input type="hidden" id="FetchcountryId"
                                                    value="<?php echo e($address['country'] ?? ''); ?>">
                                                <select id="country-dd" name="contact[country]"
                                                    class="form-control single-select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <option value="">--Select Country--</option>
                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($data->id); ?>"
                                                            <?php echo e(($address['country'] ?? '') == $data->id ? 'selected' : ''); ?>>
                                                            <?php echo e($data->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('country')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="col-md-6">
                                                <label for="state-dd" class="col-form-label text-md-end text-start">State
                                                    or
                                                    province</label>
                                                <input type="hidden" id="FetchstateId"
                                                    value="<?php echo e($address['state'] ?? ''); ?>">
                                                <select id="state-dd" name="contact[state]"
                                                    class="form-control   single-select <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <?php if(isset($address['state'])): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('state')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="city-dd"
                                                    class="col-form-label text-md-end text-start">City</label>
                                                <input type="hidden" id="FetchcityId" name="contact[city]"
                                                    value="<?php echo e($address['city'] ?? ''); ?>">
                                                <select id="city-dd" name="contact[city]"
                                                    class="form-control   single-select <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <?php if(isset($address['city'])): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('city')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="postcode" class="col-form-label text-md-end text-start">Zip or
                                                    postal
                                                    code</label>
                                                <input type="text"
                                                    class="form-control   <?php $__errorArgs = ['contact.postcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="postcode" name="contact[postcode]"
                                                    value="<?php echo e($address['postcode'] ?? ''); ?>">
                                                <?php if($errors->has('contact.postcode')): ?>
                                                    <span
                                                        class="text-danger"><?php echo e($errors->first('contact.postcode')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                               
                                <div class="page-header mt-3">
                                    <h3>General Information</h3>
                                </div>
                               
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="account" class="col-form-label text-md-end text-start">Account
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Account" id="account" name="account">
                                                <option value="">--Select--</option>
                                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($account['id']); ?>"
                                                        <?php echo e($assetGeneralInfo['accounts_id'] == $account['id'] ? 'selected' : ''); ?>>
                                                        (<?php echo e($account['code']); ?>)
                                                        <?php echo e($account['description']); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('account')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('account')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="barcode"
                                                class="col-form-label text-md-end text-start">Barcode</label>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="barcode" name="barcode"
                                                value="<?php echo e($assetGeneralInfo['barcode']); ?>">
                                            <?php if($errors->has('barcode')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('barcode')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="department" class="col-form-label text-md-end text-start">Charge
                                                Departments
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Departments" id="department" name="department">
                                                <option value="">--Select--</option>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($department['id']); ?>"
                                                        <?php echo e($assetGeneralInfo['charge_department_id'] == $department['id'] ? 'selected' : ''); ?>>
                                                        (<?php echo e($department['code']); ?>)
                                                        <?php echo e($department['description']); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('department')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('department')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="notes"
                                                class="col-form-label text-md-end text-start">Notes</label>
                                            <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="notes" id="notes" cols="48"
                                                rows="6"><?php echo $assetGeneralInfo['notes']; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userContact">

                            <div class="item_name">
                                <div class="whitebox mb-4">
                                    <div class="page-header mb-2">
                                        <h3>Asset Parts Supplies</h3>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="supplies"
                                                class="col-form-label text-md-end text-start">Part/Supply
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['supplies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Supplies" id="supplies" name="supplies">
                                                <option value="">Select</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($supply['id']); ?>"
                                                        <?php echo e(old('supplies') == $supply['id'] ? 'selected' : ''); ?>>
                                                        <?php echo e($supply['name']); ?>

                                                        (<?php echo e($supply['code']); ?>)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('supplies')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('supplies')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="quantity"
                                                class="col-form-label text-md-end text-start">Qty</label>
                                            <input type="text" id="quantity" name="quantity" class="form-control"
                                                value="<?php echo e(old('quantity')); ?>">
                                            <?php if($errors->has('quantity')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="page-header mt-4">
                                            <h3>All Parts Supplies</h3>
                                            <hr>
                                        </div>
                                        <table class="display datatable" id="PositionList" width ="100%">
                                            <thead>
                                                <tr>
                                                    <th width="3%">S#</th>
                                                    <th width="13%">Part</th>
                                                    <th width="13%">Quantity</th>
                                                    <th>Submitted By User</th>
                                                    <th>Date Submitted</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php $__empty_1 = true; $__currentLoopData = $assetPartSuppliesLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suppliesLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        if (
                                                            isset($suppliesLog->part_supply_id) &&
                                                            $suppliesLog->part_supply_id != 'NULL'
                                                        ) {
                                                            $supplyLog = \App\Models\Supplies::find(
                                                                $suppliesLog->part_supply_id,
                                                            );
                                                        } else {
                                                            $supplyLog = '';
                                                        }
                                                        if (
                                                            isset($suppliesLog->submitted_by) &&
                                                            $suppliesLog->submitted_by != 'NULL'
                                                        ) {
                                                            $submitted_by = \App\Models\User::find(
                                                                $suppliesLog->submitted_by,
                                                            );
                                                        }
                                                    ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td>
                                                            <?php if(isset($suppliesLog->part_supply_id) && $suppliesLog->part_supply_id != 'NULL'): ?>
                                                                <?php echo e($supplyLog->name ?? ''); ?>

                                                                (<?php echo e($supplyLog->code ?? ''); ?>)
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($suppliesLog->quantity ?? ''); ?></td>
                                                        <td>
                                                            <?php if(isset($suppliesLog->submitted_by) && $suppliesLog->submitted_by != 'NULL'): ?>
                                                                <a href="<?php echo e(route('users.show', $suppliesLog->submitted_by)); ?>"
                                                                    class=""><?php echo e($submitted_by->name ?? ''); ?></a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($suppliesLog->updated_at ? \Carbon\Carbon::parse($suppliesLog->updated_at)->format('jS F, Y h:i:s A') : '--'); ?>

                                                        </td>
                                                        <td>
                                                            <a data-bs-toggle="modal"
                                                                data-bs-target="#EditpartsModal_<?php echo e($suppliesLog->id); ?>"
                                                                class="link-primary"><i
                                                                    class="fa-regular fa-pen-to-square"></i></a>

                                                            <button type="button" class="link-danger"
                                                                onclick="delete_faciparts('<?php echo e(route('faciparts.delete', $suppliesLog->id)); ?>')"
                                                                data-id="<?php echo e($suppliesLog->id); ?>">
                                                                <i class="fa-solid fa-trash-can"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    
                                                    <div class="modal fade EditpartsModal"
                                                        id="EditpartsModal_<?php echo e($suppliesLog->id); ?>"
                                                        data-bs-keyboard="false" data-bs-backdrop="static">
                                                        <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <!-- Modal body -->
                                                                <div class="modal-body">
                                                                    <h6 class="modal-title">Asset Parts Supplies </h6>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"><i
                                                                            class="fa-solid fa-xmark"></i></button>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <label for="supplies_<?php echo e($suppliesLog->id); ?>"
                                                                                class="col-form-label text-md-end text-start">Part/Supply</label>
                                                                            <select class="form-control supplies-select"
                                                                                id="supplies_<?php echo e($suppliesLog->id); ?>"
                                                                                name="supplies_<?php echo e($suppliesLog->id); ?>"
                                                                                data-log-id="<?php echo e($suppliesLog->id); ?>">
                                                                                <option value="">Select</option>
                                                                                <?php $__empty_2 = true; $__currentLoopData = $supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                    <option value="<?php echo e($supply['id']); ?>"
                                                                                        <?php echo e($suppliesLog->part_supply_id == $supply['id'] ? 'selected' : ''); ?>>
                                                                                        <?php echo e($supply['name']); ?>

                                                                                        (<?php echo e($supply['code']); ?>)
                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                            <span class="invalid-feedback supplies-error"
                                                                                role="alert"></span>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <label for="quantity_<?php echo e($suppliesLog->id); ?>"
                                                                                class="col-form-label text-md-end text-start">Qty</label>
                                                                            <input type="text"
                                                                                id="quantity_<?php echo e($suppliesLog->id); ?>"
                                                                                name="quantity_<?php echo e($suppliesLog->id); ?>"
                                                                                class="form-control quantity-input"
                                                                                value="<?php echo e($suppliesLog->quantity); ?>">
                                                                            <span class="invalid-feedback quantity-error"
                                                                                role="alert"></span>
                                                                        </div>
                                                                    </div>
                                                                    <button type="button"
                                                                        class="btn btn-primary mt-3 float-end save-parts-btn"
                                                                        data-log-id="<?php echo e($suppliesLog->id); ?>">Update</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td><span class="text-info"><strong>No Logs
                                                                    Found!</strong></span></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userCareer">
                            <div class="item_name">
                                <div class="whitebox mb-4">
                                    <div class="page-header mb-2">
                                        <h3>Meter Reading</h3>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="meter_reading" class="col-form-label text-md-end text-start">Meter
                                                Reading
                                            </label>
                                            <input type="text" id="meter_reading" name="meter_reading"
                                                class="form-control" placeholder="0.00"
                                                value="<?php echo e(old('meter_reading')); ?>">
                                            <?php if($errors->has('meter_reading')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('meter_reading')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="meter_read_units"
                                                class="col-form-label text-md-end text-start">Meter
                                                Reading Units
                                            </label>
                                            <select class="form-control <?php $__errorArgs = ['meter_read_units'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Meter read units" id="meter_read_units"
                                                name="meter_read_units">
                                                <option value="">--Select--</option>
                                                <?php $__currentLoopData = $MeterReadUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meterReadUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($meterReadUnit['id']); ?>">
                                                        <?php echo e($meterReadUnit['name']); ?> (<?php echo e($meterReadUnit['symbol']); ?>)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('meter_read_units')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('meter_read_units')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="page-header mt-4">
                                            <h3>Recent Meter Readings</h3>
                                            <hr>
                                        </div>
                                        <table class="display" id="meterReadList" width ="100%">
                                            <thead>
                                                <tr>
                                                    <th scope="col">S#</th>
                                                    <th scope="col">Last Reading</th>
                                                    <th scope="col">Unit</th>
                                                    <th scope="col">Submitted By User</th>
                                                    <th scope="col">Date Submitted</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                                <?php $__empty_1 = true; $__currentLoopData = $meterReadings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        if ($reading->meter_units_id != '') {
                                                            $meterReadUnit = \App\Models\MeterReadUnits::find(
                                                                $reading->meter_units_id,
                                                            );
                                                        } else {
                                                            $meterReadUnit = '';
                                                        }
                                                        $submitted_by = \App\Models\User::find($reading->submitted_by);
                                                    ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e($reading->reading_value); ?></td>
                                                        <td>
                                                            <?php if($reading->meter_units_id): ?>
                                                                <?php echo e($meterReadUnit->name ?? ''); ?>

                                                                (<?php echo e($meterReadUnit->symbol ?? ''); ?>)
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($reading->submitted_by != ''): ?>
                                                                <a href="<?php echo e(route('users.show', $reading->submitted_by)); ?>"
                                                                    class=""><?php echo e($submitted_by->name ?? ''); ?></a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($reading->updated_at ? \Carbon\Carbon::parse($reading->updated_at)->format('jS F, Y h:i:s A') : '--'); ?>

                                                        </td>
                                                        <td>
                                                            <a data-bs-toggle="modal"
                                                                data-bs-target="#EditMeterReadModal_<?php echo e($reading->id); ?>"
                                                                class="link-primary"><i
                                                                    class="fa-regular fa-pen-to-square"></i></a>

                                                            <button type="button" class="link-danger"
                                                                onclick="delete_facimeter('<?php echo e(route('facimeter.delete', $reading->id)); ?>')"
                                                                data-id="<?php echo e($reading->id); ?>">
                                                                <i class="fa-solid fa-trash-can"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    
                                                    <div class="modal fade EditMeterReadModal"
                                                        id="EditMeterReadModal_<?php echo e($reading->id); ?>"
                                                        data-bs-keyboard="false" data-bs-backdrop="static">
                                                        <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <!-- Modal body -->
                                                                <div class="modal-body">
                                                                    <h6 class="modal-title">Meter Readings </h6>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"><i
                                                                            class="fa-solid fa-xmark"></i></button>
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <label for="meter_reading_<?php echo e($reading->id); ?>"
                                                                                class="col-form-label text-md-end text-start">Meter
                                                                                Reading
                                                                            </label>
                                                                            <input type="text"
                                                                                id="meter_reading_<?php echo e($reading->id); ?>"
                                                                                name="meter_reading_<?php echo e($reading->id); ?>"
                                                                                class="form-control reading-input"
                                                                                placeholder="0.00"
                                                                                value="<?php echo e($reading->reading_value); ?>">
                                                                            <span
                                                                                class="invalid-feedback meter_reading-error"
                                                                                role="alert"></span>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <label
                                                                                for="meter_read_units_<?php echo e($reading->id); ?>"
                                                                                class="col-form-label text-md-end text-start">Meter
                                                                                Reading Units
                                                                            </label>
                                                                            <select class="form-control meterunit-select"
                                                                                id="meter_read_units_<?php echo e($reading->id); ?>"
                                                                                name="meter_read_units_<?php echo e($reading->id); ?>"
                                                                                data-log-id="<?php echo e($reading->id); ?>">
                                                                                <option value="">--Select--
                                                                                </option>
                                                                                <?php $__empty_2 = true; $__currentLoopData = $MeterReadUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meterReadUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                    <option
                                                                                        value="<?php echo e($meterReadUnit['id']); ?>"
                                                                                        <?php echo e($reading->meter_units_id == $meterReadUnit['id'] ? 'selected' : ''); ?>>
                                                                                        <?php echo e($meterReadUnit['name']); ?>

                                                                                        (<?php echo e($meterReadUnit['symbol']); ?>)
                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                            <span class="invalid-feedback meter-error"
                                                                                role="alert"></span>
                                                                        </div>
                                                                    </div>
                                                                    <button type="button"
                                                                        class="btn btn-primary mt-3 float-end save-meter-btn"
                                                                        data-log-id="<?php echo e($reading->id); ?>">Update</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td><span class="text-info"><strong>No History
                                                                    Found!</strong></span></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="userFiles">

                            <div class="item_name">
                                <div class="whitebox mb-4">
                                    <div class="page-header mb-2">
                                        <h3>Documents</h3>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <input type="file"
                                                class="form-control <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="files"
                                                name="files[]" multiple>
                                            <?php if($errors->has('files')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('files')); ?></span>
                                            <?php endif; ?>
                                            <span class="text-muted">*Supported file type: doc, docx,
                                                xlsx, xls, ppt, pptx, txt, pdf, jpg, jpeg, png, webp, gif</span>
                                        </div>
                                        <table id="FacilityFilesList" class="display" width="100%">
                                            <thead>
                                                <tr>
                                                    <th scope="col">S#</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Description</th>
                                                    
                                                    
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $assetFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e($certificate->name); ?></td>
                                                        <td><?php echo e($certificate->description); ?></td>
                                                        
                                                        
                                                        <td><a href="<?php echo e(asset($certificate->url)); ?>"
                                                                class="btn btn-warning btn-sm" target="_blank"
                                                                title="View"><i class="bi bi-eye"></i></a>
                                                            <a data-bs-toggle="modal"
                                                                data-bs-target="#UploadFileModal_<?php echo e($certificate->af_id); ?>"
                                                                class="link-primary"><i
                                                                    class="fa-regular fa-pen-to-square"></i></a>
                                                            <button type="button" class="link-danger"
                                                                onclick="delete_savedocs('<?php echo e(route('facidocs.delete', $certificate->af_id)); ?>')"
                                                                data-id="<?php echo e($certificate->af_id); ?>">
                                                                <i class="fa-solid fa-trash-can"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    
                                                    <div class="modal fade"
                                                        id="UploadFileModal_<?php echo e($certificate->af_id); ?>"
                                                        data-bs-keyboard="false" data-bs-backdrop="static">
                                                        <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <!-- Modal body -->
                                                                <div class="modal-body">
                                                                    <h6 class="modal-title">
                                                                        <?php echo e($facility->name); ?>

                                                                        Documents</h6>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"><i
                                                                            class="fa-solid fa-xmark"></i></button>
                                                                    
                                                                    <div class=""
                                                                        id="ajaxmsgModal<?php echo e($certificate->af_id); ?>">
                                                                    </div>
                                                                    <div class="whitebox mb-4">
                                                                        <div class="col-md-8">
                                                                            <label
                                                                                for="cert_name_<?php echo e($certificate->af_id); ?>"
                                                                                class="col-form-label text-md-end text-start">Name</label>
                                                                            <input type="text" class="form-control  "
                                                                                id="cert_name_<?php echo e($certificate->af_id); ?>"
                                                                                name="cert_name_<?php echo e($certificate->af_id); ?>"
                                                                                value="<?php echo e($certificate->name); ?>">
                                                                        </div>
                                                                        <div class="col-md-12">
                                                                            <label
                                                                                for="cert_description_<?php echo e($certificate->af_id); ?>"
                                                                                class="col-form-label text-md-end text-start">Description
                                                                            </label>
                                                                            <textarea class="form-control" id="cert_description_<?php echo e($certificate->af_id); ?>"
                                                                                name="cert_description_<?php echo e($certificate->af_id); ?>" rows="2"><?php echo e($certificate->description); ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <button type="button"
                                                                        class="btn btn-primary mt-3 float-end save-docs-btn"
                                                                        data-log-id="<?php echo e($certificate->af_id); ?>">Update</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <td></td>
                                                    <td></td>
                                                    
                                                    <td><span class="text-info"><strong>No Documents
                                                                Found!</strong></span></td>
                                                    
                                                    
                                                    <td></td>
                                                <?php endif; ?>
                                            </tbody>
                                            
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <?php $__env->startPush('javascript'); ?>
        <script>
            jQuery(document).ready(function() {
                $('#myTabs a').click(function(e) {
                    e.preventDefault()
                    $(this).tab('show')
                })
            });
        </script>
        <script>
            function getRandomInt(min, max) {
                return Math.floor(Math.random() * (max - min + 1)) + min;
            }
            $(document).ready(function() {
                var i = 1;
                var newName = 'New Facility #';
                var newCode = 'F' + getRandomInt(1000, 9999);
                if ($('#name').val() == '') {
                    $('#name').val(newName + newCode);
                }
                if ($('#code').val() == '') {
                    $('#code').val(newCode);
                }
                i = i++;
            });
        </script>
        <script>
            var FetchcountryId = $('#FetchcountryId').val();
            var FetchstateId = $('#FetchstateId').val();
            var FetchcityId = $('#FetchcityId').val();
            $(document).ready(function() {
                $('#country-dd').on('change', function() {
                    var idCountry = this.value;
                    $("#state-dd").html('');
                    $.ajax({
                        url: "<?php echo e(url('api/fetch-states')); ?>",
                        type: "POST",
                        data: {
                            country_id: idCountry,
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        dataType: 'json',
                        success: function(result) {
                            $('#state-dd').html('<option value="">--Select State--</option>');
                            $.each(result.states, function(key, value) {
                                $("#state-dd").append('<option value="' + value.id + '" ' +
                                    (value.id == FetchstateId ? 'selected' : '') +
                                    '>' + value.name + '</option>');
                            });
                            $('#city-dd').html('<option value="">--Select City--</option>');
                        }
                    });
                });
                $('#state-dd').on('change', function() {
                    var idState = this.value;
                    $("#city-dd").html('');
                    $.ajax({
                        url: "<?php echo e(url('api/fetch-cities')); ?>",
                        type: "POST",
                        data: {
                            state_id: idState,
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        dataType: 'json',
                        success: function(res) {
                            $('#city-dd').html('<option value="">--Select City--</option>');
                            $.each(res.cities, function(key, value) {
                                $("#city-dd").append('<option value="' + value.id + '" ' +
                                    (value.id == FetchcityId ? 'selected' : '') +
                                    '>' + value.name + '</option>');
                            });
                        }
                    });
                });
            });
        </script>
        <script>
            function fetchLocationName(id, type) {
                $.ajax({
                    url: "<?php echo e(url('get-location-name')); ?>/" + id + "/" + type,
                    type: "GET",
                    dataType: 'json',
                    success: function(result) {
                        $(`#${type}-dd`).text(result.name);
                        $(`#${type}-dd`).append(`<option value="${id}">${result.name}</option>`);
                    },
                    error: function(error) {
                        console.error('Error fetching location name:', error);
                    }
                });
            }

            $(document).ready(function() {
                // var FetchcountryId = $('#FetchcountryId').val();
                var FetchstateId = $('#FetchstateId').val();
                var FetchcityId = $('#FetchcityId').val();

                // fetchLocationName(FetchcountryId, 'country');
                fetchLocationName(FetchstateId, 'state');
                fetchLocationName(FetchcityId, 'city');
            });
        </script>
        <script>
            $(document).ready(function() {
                // Function to toggle dropdown based on radio input selection
                function toggleDropdown() {
                    $('#parent_equipment').val('');
                    $('#old_faci_addr').show();
                    $('#faci_new_addr').hide();
                }
                // Function to toggle new address based on radio input selection
                function toggleNewAddr() {
                    $('#parent_address_warning').hide();
                    $('#address_success').hide();
                    $('#parent_id').val('');
                    $('#faci_new_addr').show();
                    $('#old_faci_addr').hide();
                }
                // Trigger click event based on the initial state of the radio input
                if ($('#old_faci_chkbox').prop('checked')) {
                    toggleDropdown();
                } else if ($('#new_faci_chkbox').prop('checked')) {
                    toggleNewAddr();
                }
                // Click event handler for radio inputs
                $('#old_faci_chkbox').click(function() {
                    toggleDropdown();
                });
                $('#new_faci_chkbox').click(function() {
                    toggleNewAddr();
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#parent_id').change(function() {
                    var parentId = $(this).val();
                    var url = "<?php echo e(url('get-parent-address')); ?>" + '/' + parentId;
                    // Send an AJAX request to retrieve the latest address
                    if (parentId != '') {
                        $.ajax({
                            url: url,
                            type: 'GET',
                            success: function(response) {
                                // Update the address span with the retrieved address
                                if (response.address) {
                                    $('#parent_address_warning').hide();
                                    // Update the address or whatever element you want to display the address
                                    $('#address_success').show();

                                    var addressString = response.address;
                                    if (response.city) {
                                        addressString += ', ' + response.city;
                                    }
                                    if (response.state) {
                                        addressString += ', ' + response.state;
                                    }
                                    if (response.country) {
                                        addressString += ', ' + response.country;
                                    }
                                    if (response.postcode) {
                                        addressString += ', Postcode: ' + response.postcode;
                                    }
                                    $('#address_success').text(addressString).removeClass(
                                        'text-info').addClass('text-success');
                                } else {
                                    // If no address is found, display a warning
                                    $('#parent_address_warning').show();
                                    // Clear the address element
                                    $('#address_success').hide().text('');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                            }
                        });
                    } else {
                        $('#parent_address_warning').hide();
                        $('#address_success').show();
                        $('#address_success').text('').removeClass('text-success');
                        $('#address_success').text(
                            'If this facility is not part of another location,then please select other checkbox and manually enter the address.'
                        ).addClass('text-info');
                        // toggleNewAddr();
                        // $('#new_address_field').show();
                    }
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('.save-parts-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var suppliesId = $('#supplies_' + logId).val();
                    var quantity = $('#quantity_' + logId).val();

                    var url = "<?php echo e(route('save.faciparts')); ?>";
                    var data = {
                        log_id: logId,
                        supplies_id: suppliesId,
                        quantity: quantity,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#EditpartsModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_faciparts(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',

                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
        <script>
            $(document).ready(function() {
                $('.save-meter-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var meterunitId = $('#meter_read_units_' + logId).val();
                    var meterreading = $('#meter_reading_' + logId).val();

                    var url = "<?php echo e(route('save.facimeter')); ?>";
                    var data = {
                        log_id: logId,
                        meterunit_id: meterunitId,
                        meterreading: meterreading,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#EditMeterReadModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_facimeter(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',

                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
        <script>
            $(document).ready(function() {
                $('.save-docs-btn').click(function() {
                    var logId = $(this).data('log-id');
                    var docsName = $('#cert_name_' + logId).val();
                    var docsDescription = $('#cert_description_' + logId).val();

                    var url = "<?php echo e(route('save.facidocs')); ?>";
                    var data = {
                        log_id: logId,
                        docsName: docsName,
                        docsDescription: docsDescription,
                        _token: '<?php echo e(csrf_token()); ?>'
                    };

                    $.ajax({
                        url: url,
                        type: 'PUT',
                        data: data,
                        success: function(response) {
                            // Handle success response
                            console.log(response);
                            if (response.hasOwnProperty('success')) {
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle',
                                        icon: 'SwalToastBoxIcon',
                                        popup: 'SwalToastBoxhtml'
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast.fire({
                                    icon: "success",
                                    title: response.success
                                });
                            }
                            // Close modal if needed
                            $('#UploadFileModal_' + logId).modal('hide');
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr) {
                            // Handle error response
                            var errors = xhr.responseJSON.errors;
                            if (errors) {
                                var errorMessage = xhr.responseJSON.message || 'An error occurred';
                                var errorList = '';
                                for (var key in errors) {
                                    if (errors.hasOwnProperty(key)) {
                                        errorList += errors[key].join('<br>') + '<br>';
                                    }
                                }
                                const Toast1 = Swal.mixin({
                                    toast: true,
                                    position: "top-end",
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        title: 'SwalToastBoxtitle', // Add your custom class here
                                        icon: 'SwalToastBoxIcon', // Add your custom class here
                                        popup: 'SwalToastBoxhtml' // Add your custom class here
                                    },
                                    didOpen: (toast) => {
                                        toast.onmouseenter = Swal.stopTimer;
                                        toast.onmouseleave = Swal.resumeTimer;
                                    }
                                });
                                Toast1.fire({
                                    icon: "error",
                                    title: errorMessage,
                                    html: errorList
                                });
                            }
                        }
                    });

                });
            });
        </script>
        <script>
            function delete_savedocs(url, targetId) {
                if (confirm("Are you sure to Permanently Delete?")) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',

                        success: function(response) {
                            swal("Success", response.success, "success");
                            setTimeout(function() {
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            swal("Error!", error, "error");
                        }
                    });
                }
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/busfaypa/public_html/webiconnect.net/dev/pms/resources/views/facilities/edit.blade.php ENDPATH**/ ?>