<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <div class="wrapper">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3>Supplies List</h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-supply')): ?>
                        <a href="<?php echo e(route('supplies.create')); ?>" class="btn btn-primary float-end"><i
                                class="bi bi-plus-circle"></i>
                            Add New
                            Supply</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="whitebox">
                <table id="SupplyList" class="table table-striped nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">S#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Code</th>
                            <th scope="col">Location</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($supply->name); ?></td>
                                <td><?php echo e($supply->code); ?></td>
                                <?php
                                    $stockCount = count($supply->stocks);
                                ?>
                                <td style="<?php echo e($stockCount <= 1 ? '' : 'color: #2993c6; cursor: pointer;'); ?>">

                                    <?php if($stockCount <= 1): ?>
                                        <?php $__currentLoopData = $supply->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($facilities[$stock->parent_id])): ?>
                                                <?php echo e($facilities[$stock->parent_id]); ?> (aisle: <?php echo e($stock->stocks_aisle); ?>,
                                                row: <?php echo e($stock->stocks_row); ?>, bin: <?php echo e($stock->stocks_bin); ?>)<br>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span class="multiple-locations-<?php echo e($supply->id); ?>" title="Show Locations">Multiple
                                            Locations</span>
                                        <div id="locations-list-<?php echo e($supply->id); ?>" style="display: none;">
                                            <?php $__currentLoopData = $supply->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($facilities[$stock->parent_id])): ?>
                                                    <?php echo e($loop->iteration); ?>. <?php echo e($facilities[$stock->parent_id]); ?> (aisle:
                                                    <?php echo e($stock->stocks_aisle); ?>,
                                                    row: <?php echo e($stock->stocks_row); ?>, bin: <?php echo e($stock->stocks_bin); ?>)<br>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php $__env->startPush('javascript'); ?>
                                        <script>
                                            $(document).ready(function() {
                                                $('.multiple-locations-<?php echo e($supply->id); ?>').click(function() {
                                                    $('#locations-list-<?php echo e($supply->id); ?>').dialog({
                                                        modal: true,
                                                        title: "Multiple Locations",
                                                        width: 400,
                                                        resizable: false,
                                                        buttons: {
                                                            "Close": function() {
                                                                $(this).dialog('close');
                                                            }
                                                        }
                                                    });
                                                });
                                            });
                                        </script>
                                    <?php $__env->stopPush(); ?>

                                </td>
                                
                                
                                <td>
                                    <form action="<?php echo e(route('supplies.destroy', $supply->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-supply')): ?>
                                            <a href="<?php echo e(route('supplies.edit', $supply->id)); ?>" class="link-primary"><i
                                                    class="fa-regular fa-pen-to-square"></i></a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-supply')): ?>
                                            <button type="submit" class="link-danger"
                                                onclick="return confirm('Do you want to delete this supply?');"><i
                                                    class="fa-solid fa-trash-can"></i></button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td></td>
                            <td></td>
                            <td>
                                <span class="text-danger">
                                    <strong>No Supply Found!</strong>
                                </span>
                            </td>
                            <td></td>
                            <td></td>
                        <?php endif; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
    <?php $__env->startPush('javascript'); ?>
        
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/busfaypa/public_html/webiconnect.net/dev/pms/resources/views/supplies/index.blade.php ENDPATH**/ ?>