<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <div class="wrapper">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <div class="page-header">
                    <h1>Dashboard</h1>
                </div>
                <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                        class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
            </div>
            <div class="row boxs">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info card-img-holder">
                        <div class="inner">
                            <img src="<?php echo e(asset('img/circle-box.svg')); ?>" class="card-img-absolute">
                            <h3>150</h3>
                            <p>New Orders</p>
                            <a href="#" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success card-img-holder">
                        <div class="inner">
                            <img src="<?php echo e(asset('img/circle-box.svg')); ?>" class="card-img-absolute">
                            <h3>53<sup style="font-size: 20px">%</sup></h3>
                            <p>Bounce Rate</p>

                            <a href="#" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning card-img-holder">
                        <div class="inner">
                            <img src="<?php echo e(asset('img/circle-box.svg')); ?>" class="card-img-absolute">
                            <h3>44</h3>
                            <p>User Registrations</p>
                            <a href="#" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger card-img-holder">
                        <div class="inner">
                            <img src="<?php echo e(asset('img/circle-box.svg')); ?>" class="card-img-absolute">
                            <h3>65</h3>
                            <p>Unique Visitors</p>
                            <a href="#" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/index.blade.php ENDPATH**/ ?>