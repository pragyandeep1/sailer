<?php $__env->startSection('content'); ?>
    <?php
        // echo '<pre>';
        // echo json_encode($equipments);
        // echo '<br>';
        // print_r($equipmentRelations);
        // echo json_encode($equipmentRelations);
        // echo '</pre>';
    ?>
    <!-- Begin Page Content -->
    <div class="page-content container">
        <div class="wrapper">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="page-header">
                        <h3>Equipment List</h3>
                    </div>
                </div>
                <div class="col-md-3">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-equipment')): ?>
                        <a href="<?php echo e(route('equipments.create')); ?>" class="btn btn-primary float-end"><i
                                class="bi bi-plus-circle"></i>
                            Add New
                            Equipment</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="whitebox">
                <table id="EquipmentsList" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Location</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
    <?php $__env->startPush('javascript'); ?>
        <script>
            const positions = <?php echo json_encode($equipmentRelations, 15, 512) ?>;

            // Map the sorted positions to organisationData
            const organisationData = positions.map(position => ({
                tt_key: position.id,
                tt_parent: position.parent_id ? position.parent_id : 0,
                name: position.name,
                status: position.status == 1 ?
                    '<input type="button" class="equipment_status btn btn-success" value="Active">' :
                    '<input type="button" class="equipment_status btn btn-secondary" value="Disabled">',
                action: `<form id="deleteForm${position.id}" action="<?php echo e(route('equipments.destroy', '')); ?>/${position.id}" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a href="<?php echo e(url('equipments')); ?>/${position.id}/edit" class="link-primary"><i class="fa-regular fa-pen-to-square"></i></a>
                <button type="submit" class="link-danger" onclick="return confirm('Do you want to delete this equipment?');"><i class="fa-solid fa-trash-can"></i></button>
            </form>`
            }));
            console.log(organisationData);
            // Initializing TreeTable with the extracted data
            $('#EquipmentsList').treeTable({
                "data": organisationData,
                "columns": [{
                        "data": "name"
                    },
                    {
                        "data": "name"
                    },
                    {
                        "data": "status"
                    },
                    {
                        "data": "action",
                        "render": function(data, type, row) {
                            return row.action;
                        }
                    }
                ],
                order: [
                    [1, 'asc'],
                ]
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/busfaypa/public_html/webiconnect.net/dev/pms/resources/views/equipments/index.blade.php ENDPATH**/ ?>