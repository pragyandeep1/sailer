 </div>
 <!-- End of Main Content -->

 <!-- Footer -->
 <footer class="sticky-footer bg-white">
     <div class="container my-auto">
         <div class="copyright text-center my-auto">
             <span>Copyright &copy;
                 <script>
                     document.write(new Date().getFullYear())
                 </script> Sailorcom
             </span>
         </div>
     </div>
 </footer>
 <!-- End of Footer -->

 </div>
 <!-- End of Content Wrapper -->

 </div>
 <!-- End of Page Wrapper -->


 <!-- Scroll to Top Button-->
 <div id="backto-top"><i class="fa-solid fa-arrow-up"></i></div>

 <!-- Logout Modal-->
 


 <!-- Bootstrap core JavaScript-->
 <script src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/sb-admin-2.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/jquery.fancybox.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/jquery.dataTables.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/dataTables.bootstrap5.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/dataTables.responsive.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/select2.min.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/treeTable.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/method.js')); ?>"></script>
 <script src="https://cdn.ckeditor.com/4.13.0/full/ckeditor.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 <script src="https://cdn.datatables.net/select/1.7.0/js/dataTables.select.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

 <script src="<?php echo e(asset('public/js/custom.js')); ?>"></script>
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
 <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">


 <script>
     $(document).ready(function() {
         $('#SuppliesList,#FacilityFilesList, #PositionList, #UserCareerList, #UsersFilesList, #RolesList, #ToolsList, #UsersList,#ProductsList,#BusinessFilesList,#StockList,#InventoryList,#SupplyBomList,#meterReadList')
             .DataTable({
                 responsive: true
             });
     });
 </script>
 <script>
     $(document).ready(function() {
         // Store the active tab when a tab is shown
         $('a[data-bs-toggle="tab"]').on('show.bs.tab', function(e) {
             localStorage.setItem('activeTab', $(e.target).attr('href'));
         });

         // Get the active tab from localStorage
         var activeTab = localStorage.getItem('activeTab');

         // If there is an active tab stored, show it
         if (activeTab) {
             $('.nav-tabs a[href="' + activeTab + '"]').tab('show');
         }
         // Clear localStorage when leaving any edit page
         $('a[href*="edit"]').on('click', function() {
             localStorage.removeItem('activeTab');
         });
     });
 </script>
 <script>
     jQuery(".select2-multiple").select2({
         theme: "bootstrap",
         placeholder: "--Select--",
         maximumSelectionSize: 6,
         containerCssClass: ':all:'
     });
 </script>

 <?php if($message = Session::get('success')): ?>
     <script>
         jQuery(document).ready(function() {
             const Toast = Swal.mixin({
                 toast: true,
                 position: "top-end",
                 showConfirmButton: false,
                 timer: 3000,
                 timerProgressBar: true,
                 customClass: {
                     title: 'SwalToastBoxtitle', // Add your custom class here
                     icon: 'SwalToastBoxIcon', // Add your custom class here
                     popup: 'SwalToastBoxhtml' // Add your custom class here
                 },
                 didOpen: (toast) => {
                     toast.onmouseenter = Swal.stopTimer;
                     toast.onmouseleave = Swal.resumeTimer;
                 }
             });
             Toast.fire({
                 icon: "success",
                 title: "<?php echo e($message); ?>"
             });
         });
     </script>
     
 <?php elseif($message = Session::get('error')): ?>
     <script>
         jQuery(document).ready(function() {
             const Toast = Swal.mixin({
                 toast: true,
                 position: "top-end",
                 showConfirmButton: false,
                 timer: 3000,
                 timerProgressBar: true,
                 customClass: {
                     title: 'SwalToastBoxtitle', // Add your custom class here
                     icon: 'SwalToastBoxIcon', // Add your custom class here
                     popup: 'SwalToastBoxhtml' // Add your custom class here
                 },
                 didOpen: (toast) => {
                     toast.onmouseenter = Swal.stopTimer;
                     toast.onmouseleave = Swal.resumeTimer;
                 }
             });
             Toast.fire({
                 icon: "error",
                 title: "<?php echo e($message); ?>"
             });
         });
     </script>
     
 <?php endif; ?>
 </body>

 </html>
<?php /**PATH /home2/busfaypa/public_html/webiconnect.net/dev/pms/resources/views/layout/footer.blade.php ENDPATH**/ ?>